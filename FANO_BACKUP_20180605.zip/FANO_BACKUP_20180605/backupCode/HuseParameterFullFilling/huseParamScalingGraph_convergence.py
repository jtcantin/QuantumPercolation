import numpy as np
import scipy.stats
import sys
import matplotlib
#matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.ticker as tickerMod

np.set_printoptions(threshold=1000,linewidth=2000,precision=4,suppress=False)

dataFileList = sys.argv[1:-1]
reduceWval = float(sys.argv[-1])

numDataFiles = len(dataFileList)

for file_iter in range(numDataFiles):
    dataFile = dataFileList[file_iter]
    data_2Darray = np.loadtxt(dataFile).T

    sortStack = np.vstack((data_2Darray[2,:],data_2Darray[1,:],data_2Darray[0,:]))

    data_2Darray_Nqw_srtd_indices = np.lexsort(sortStack)

    data_2Darray_Nqw_srtd = data_2Darray[:,data_2Darray_Nqw_srtd_indices]



    numDataPoints = len(data_2Darray[0,:])

    NPlotArray = data_2Darray_Nqw_srtd[0,:].astype(np.int_)
    qPlotArray = data_2Darray_Nqw_srtd[1,:]
    wPlotArray = data_2Darray_Nqw_srtd[2,:]
    huseParamPlotArray = data_2Darray_Nqw_srtd[3,:]
    varPlotArray = data_2Darray_Nqw_srtd[5,:]
    numDisArray = data_2Darray_Nqw_srtd[8,:]


    stdErrorArray = np.sqrt(varPlotArray)/np.sqrt(numDisArray)
    alphaCI = 0.05
    CI_multValueArray = scipy.stats.t.ppf(1. - (alphaCI/2.), numDisArray-1)
    errorBar_CI_array = stdErrorArray * CI_multValueArray

    #print NPlotArray
    #print qPlotArray
    print wPlotArray
    print huseParamPlotArray
    #print varPlotArray
    #print numDisArray
    #print CI_multValueArray

    uniqueNvalues = np.unique(NPlotArray)

    print uniqueNvalues

    l_w = 1.5
    fs=17
    linestyleArray = ["-","--",":"]
    for iter in range(uniqueNvalues.size):
        figNum = iter
        fig = plt.figure(figNum,facecolor="white")
        fig.canvas.set_window_title("N = {0}".format(uniqueNvalues[iter]))
        ax = plt.subplot()

        ax.tick_params(axis="both",width=l_w,which="both")
        ax.tick_params(axis="both",length=5,which="major")
        ax.tick_params(axis="both",length=3,which="minor")
        #ax.yaxis.set_tick_params(width=l_w)
        ax.spines['top'].set_linewidth(l_w)
        ax.spines['bottom'].set_linewidth(l_w)
        ax.spines['left'].set_linewidth(l_w)
        ax.spines['right'].set_linewidth(l_w)
        
        plt.yticks(fontsize=fs)
        plt.xticks(fontsize=fs)
        plt.xlabel(r'$W$',fontsize=fs)
        plt.ylabel(r'$\langle r \rangle$',fontsize=fs)
        plt.ylim(0.38,0.54)
        plt.axhline(y=float(2.*np.log(2)-1), color='grey', ls='--', lw=l_w)
        plt.axhline(y=float(0.5295),color='grey',ls='--',lw=l_w)


    for iter in range(uniqueNvalues.size):
        figNum = iter
        fig = plt.figure(figNum,facecolor="white")
    #    ax = plt.subplot()
        N_val = uniqueNvalues[iter]
        
        wToPlot = wPlotArray[np.where(NPlotArray==N_val)]
        huseParamToPlot = huseParamPlotArray[np.where(NPlotArray==N_val)]
        errorBar_CI_ToPlot = errorBar_CI_array[np.where(NPlotArray==N_val)]
        
        print "N = ", N_val
        print wToPlot
        print huseParamToPlot

        line = plt.errorbar(wToPlot/reduceWval,huseParamToPlot,yerr=errorBar_CI_ToPlot,marker=".",label="numDis = {0}".format(int(numDisArray[0])),linestyle=linestyleArray[iter])








for iter in range(uniqueNvalues.size):
    figNum = iter
    fig = plt.figure(figNum,facecolor="white")

    plt.legend()

    plt.tight_layout()

plt.show()

figureFilename = "huseParam1DPlot.eps"
#fig.savefig(figureFilename, format='eps', dpi=1200)
fig.savefig(figureFilename, format='eps', dpi=150)
#fig.savefig(figureFilename, format='pdf', dpi=300)

plt.show()









