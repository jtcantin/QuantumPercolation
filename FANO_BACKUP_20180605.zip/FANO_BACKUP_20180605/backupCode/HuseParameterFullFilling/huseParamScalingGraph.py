import numpy as np
import scipy.stats
import sys
import matplotlib
#matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.ticker as tickerMod

np.set_printoptions(threshold=1000,linewidth=2000,precision=4,suppress=False)

dataFile = sys.argv[1]
reduceWval = float(sys.argv[2])

data_2Darray = np.loadtxt(dataFile).T

#print data_2Darray

sortStack = np.vstack((data_2Darray[2,:],data_2Darray[1,:],data_2Darray[0,:]))

#print data_2Darray[:3,:]
data_2Darray_Nqw_srtd_indices = np.lexsort(sortStack)

data_2Darray_Nqw_srtd = data_2Darray[:,data_2Darray_Nqw_srtd_indices]

#print data_2Darray_Nqw_srtd

#unique_qVals_1Darray = np.unique(np.around(data_2Darray_Nqw_srtd[1,:],decimals=3))
#unique_wVals_1Darray = np.unique(np.around(data_2Darray_Nqw_srtd[2,:],decimals=3))
#
#print unique_qVals_1Darray
#print unique_wVals_1Darray

numDataPoints = len(data_2Darray[0,:])

#for iter in range(numDataPoints):
#    for jiter in range(numDataPoints):
#
#        stdError = stdDevB/np.sqrt(numDataValues)
#    
#        tDistFactor = spStat.t.ppf(1. - (alphaCI/2.), numDataValues-1)
#        errorBarHalf = tDistFactor * stdError

NPlotArray = data_2Darray_Nqw_srtd[0,:].astype(np.int_)
qPlotArray = data_2Darray_Nqw_srtd[1,:]
wPlotArray = data_2Darray_Nqw_srtd[2,:]
huseParamPlotArray = data_2Darray_Nqw_srtd[3,:]
varPlotArray = data_2Darray_Nqw_srtd[5,:]
numDisArray = data_2Darray_Nqw_srtd[8,:]


stdErrorArray = np.sqrt(varPlotArray)/np.sqrt(numDisArray)
alphaCI = 0.05
CI_multValueArray = scipy.stats.t.ppf(1. - (alphaCI/2.), numDisArray-1)
errorBar_CI_array = stdErrorArray * CI_multValueArray

#print NPlotArray
#print qPlotArray
print wPlotArray
print huseParamPlotArray
#print varPlotArray
#print numDisArray
#print CI_multValueArray

uniqueNvalues = np.unique(NPlotArray)

print uniqueNvalues

figNum = 1
fig = plt.figure(figNum,facecolor="white")
ax = plt.subplot()
linestyleArray = ["-","--",":"]

for iter in range(uniqueNvalues.size):
    N_val = uniqueNvalues[iter]
    
    wToPlot = wPlotArray[np.where(NPlotArray==N_val)]
    huseParamToPlot = huseParamPlotArray[np.where(NPlotArray==N_val)]
    errorBar_CI_ToPlot = errorBar_CI_array[np.where(NPlotArray==N_val)]
    
    print "N = ", N_val
    print wToPlot
    print huseParamToPlot

    line = ax.errorbar(wToPlot/reduceWval,huseParamToPlot,yerr=errorBar_CI_ToPlot,marker=".",label="N = {0}".format(N_val),color="k",linestyle=linestyleArray[iter])


l_w = 1.5
fs=17

plt.yticks(fontsize=fs)
plt.xticks(fontsize=fs)
plt.xlabel(r'$W$',fontsize=fs)
plt.ylabel(r'$\langle r \rangle$',fontsize=fs)
plt.ylim(0.38,0.54)
plt.axhline(y=float(2.*np.log(2)-1),color='grey',ls='--',lw=l_w)
plt.axhline(y=float(0.5295),color='grey',ls='--',lw=l_w)

ax.tick_params(axis="both",width=l_w,which="both")
ax.tick_params(axis="both",length=5,which="major")
ax.tick_params(axis="both",length=3,which="minor")
#ax.yaxis.set_tick_params(width=l_w)
ax.spines['top'].set_linewidth(l_w)
ax.spines['bottom'].set_linewidth(l_w)
ax.spines['left'].set_linewidth(l_w)
ax.spines['right'].set_linewidth(l_w)

ax.legend()

if reduceWval == 1:
    ax.arrow(37, 0.44, 0, -0.033, head_width=1, head_length=0.005, fc='k', ec='k', width=0.2)
    plt.text(37.75, 0.43, "N", fontsize=fs,color="k")
    plt.text(35, 0.51, "Isotropic, 3D", fontsize=fs,color="k")

if reduceWval == 2:
    plt.text(30, 0.4025, "No Scaling", fontsize=fs-3,color="k")
    plt.text(31, 0.51, "Anisotropic, 3D", fontsize=fs,color="k")

plt.text(0, 0.532, "GOE", fontsize=fs-5,color="k")
plt.text(0, 0.387, "Poissonian", fontsize=fs-5,color="k")

plt.tight_layout()

#plt.show()

figureFilename = "huseParam1DPlot.eps"
#fig.savefig(figureFilename, format='eps', dpi=1200)
fig.savefig(figureFilename, format='eps', dpi=150)
#fig.savefig(figureFilename, format='pdf', dpi=300)

plt.show()









