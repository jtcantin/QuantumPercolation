import numpy as np
import sys

np.set_printoptions(threshold=10000,linewidth=2000,precision=16,suppress=False)

JTCfile = sys.argv[1]
TRXfile = sys.argv[2]

JTC_1Darray = np.loadtxt(JTCfile)
TRX_1Darray = np.loadtxt(TRXfile)

#print JTC_1Darray
#print TRX_1Darray
#print JTC_1Darray[:,0]
#print TRX_1Darray[:,0]
#print JTC_1Darray[:,1]
#print TRX_1Darray[:,1]
print "Eigenvalue Max Relative Difference:"
print np.max(np.abs((JTC_1Darray[:,0]-TRX_1Darray[:,0])/TRX_1Darray[:,0]))

print "IPR Max Relative Difference:"
print np.max(np.abs((JTC_1Darray[:,1]-TRX_1Darray[:,1])/TRX_1Darray[:,1]))

