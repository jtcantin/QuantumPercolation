import matplotlib.pyplot as plt
import numpy as np
import sys
from os import listdir
from os.path import isfile, join

np.set_printoptions(threshold=10000,linewidth=2000,precision=4,suppress=False)

dirList = sys.argv[1:]
numDir = len(dirList)

numSites_1Darray = np.zeros(numDir,dtype=np.int_)
qValue_1Darray = np.zeros(numDir,dtype=np.int_)
rangeValue_1Darray = np.zeros(numDir)
wValue_1Darray = np.zeros(numDir)
fileList = []

for iter in range(0,numDir):
    directory = dirList[iter]

    dirFiles = [ f for f in listdir(directory) if (isfile(join(directory,f)) and f!="._.DS_Store" and f!=".DS_Store") ]

    inputFilename = [x for x in dirFiles if "dis_in" in x.split("/")[-1]][0]
    inputFile = open(join(directory,inputFilename),'r')
    fileLines = inputFile.readlines()

    numSites = int(fileLines[1])
    qValue = int(fileLines[9])
    rangeValue = float(fileLines[5])
    wValue = float(inputFilename.split("_")[4][1:])

    numSites_1Darray[iter] = numSites
    qValue_1Darray[iter] = qValue
    rangeValue_1Darray[iter] = rangeValue
    wValue_1Darray[iter] = wValue
    
    dataFilename = [x for x in dirFiles if "Eval" in x.split("/")[-1]][0]
    fileList.append(join(directory,dataFilename))

#    print numSites
#    print qValue
#    print range
#    print wValue



figNum = 0
figNum += 1
fig = plt.figure(figNum,facecolor="white")
ax = plt.subplot()
firstGap_1Darray = np.zeros(numDir)

for iter in range(0,numDir):
    filename = fileList[iter]
    eigenvalue_1Darray = np.loadtxt(filename)
    
#    numSites = numSites_1Darray[iter]
#    qValue = qValue_1Darray[iter]
#    rangeValue = rangeValue_1Darray[iter]
#    wValue = wValue_1Darray[iter]

#    systemSize = numSites_1Darray[iter]
#    systemSize_1Darray = numSites*np.ones(eigenvalue_1Darray.size)

    firstGap_1Darray[iter] = eigenvalue_1Darray[-1]-eigenvalue_1Darray[-2]

#Sort data according to system size, then range
data_2Darray = np.vstack((numSites_1Darray,qValue_1Darray,rangeValue_1Darray,wValue_1Darray,firstGap_1Darray))

data_2DArray_Nr_srtd_indices = np.lexsort(np.vstack((rangeValue_1Darray,numSites_1Darray)))

data_2DArray_Nr_srtd = data_2Darray[:,data_2DArray_Nr_srtd_indices]

#Get Unique sizes
uniqueSizes, sizeCounts = np.unique(numSites_1Darray,return_counts=True)
numUniqueSizes = uniqueSizes.size
#print rangeCounts
#print uniqueRanges

print data_2DArray_Nr_srtd

#Plot data for each range
for iter in range(0,numUniqueSizes):
    sizeValue = uniqueSizes[iter]
    toPlot_indices = np.where(data_2DArray_Nr_srtd[0]==sizeValue)
    gapToPlot_1Darray = data_2DArray_Nr_srtd[4][toPlot_indices]
    rangeToPlot_1Darray = data_2DArray_Nr_srtd[2][toPlot_indices]

    print sizeValue
    print gapToPlot_1Darray
    print rangeToPlot_1Darray
    
    labelText = r'$N = {0:.1f}$'.format(sizeValue)

    line, = ax.plot(rangeToPlot_1Darray,gapToPlot_1Darray,label=labelText)#,marker="o")


l_w = 1.5
fs = 20
fs2 = 20

line, = ax.plot([3,3],[-1E8,1E5],"r:")

plt.xlabel(r'Hopping Parameter Exponent, $\alpha$', fontsize=fs,labelpad=10)
plt.ylabel(r'Gap Energy $\left(\tilde t\right)$', fontsize=fs)
fig.canvas.set_window_title("EigenvalueGapPlot")



plt.yticks(fontsize=fs)
plt.xticks(fontsize=fs)

ax.tick_params(axis="both",width=l_w,which="both")
ax.tick_params(axis="both",length=5,which="major")
ax.tick_params(axis="both",length=3,which="minor")
##ax.yaxis.set_tick_params(width=l_w)
ax.spines['top'].set_linewidth(l_w)
ax.spines['bottom'].set_linewidth(l_w)
ax.spines['left'].set_linewidth(l_w)
ax.spines['right'].set_linewidth(l_w)

ax.legend()
ax.set_yscale("log", nonposx='clip')
ax.set_xscale("log", nonposx='clip')
#plt.ylim(0,N)
plt.xlim(1E-3,1E3)

fig.tight_layout()

figureFilename = "energyGapVsAlpha.jpeg"
#fig.savefig(figureFilename, format='eps', dpi=1200)
#fig.savefig(figureFilename, format='pdf', dpi=300)
fig.savefig(figureFilename, format='jpeg', dpi=600)


plt.show()
