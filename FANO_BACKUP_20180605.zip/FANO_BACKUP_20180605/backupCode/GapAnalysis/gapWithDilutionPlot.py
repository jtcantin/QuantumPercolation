import matplotlib.pyplot as plt
import numpy as np
import sys
from os import listdir
from os.path import isfile, join, isdir

np.set_printoptions(threshold=10000,linewidth=2000,precision=4,suppress=False)

dataDir = sys.argv[1]
dirList = [ join(dataDir,f) for f in listdir(dataDir) if (isdir(join(dataDir,f)) and f!="._.DS_Store" and f!=".DS_Store") ]
numDir = len(dirList)
print numDir

numSites_1Dlist = []
qValue_1Dlist = []
rangeValue_1Dlist = []
wValue_1Dlist = []
fileList = []

for iter in range(0,numDir):
    directory = dirList[iter]

    dirFiles = [ f for f in listdir(directory) if (isfile(join(directory,f)) and f!="._.DS_Store" and f!=".DS_Store") ]

    inputFilename = [x for x in dirFiles if "dis_in" in x.split("/")[-1]][0]
    inputFile = open(join(directory,inputFilename),'r')
    fileLines = inputFile.readlines()

    numSites = int(fileLines[1])
    qValue = int(fileLines[9])
    rangeValue = float(fileLines[5])
    wValue = float(inputFilename.split("_")[4][1:])


    
    dataFilenames = [x for x in dirFiles if "Eval" in x.split("/")[-1]]
    
#    print dataFilenames

    for filename in dataFilenames:
        fileList.append(join(directory,filename))

        numSites_1Dlist.append(numSites)
        qValue_1Dlist.append(qValue)
        rangeValue_1Dlist.append(rangeValue)
        wValue_1Dlist.append(wValue)

#    print numSites
#    print qValue
#    print range
#    print wValue

numSites_1Darray = np.array(numSites_1Dlist)
qValue_1Darray = np.array(qValue_1Dlist)
rangeValue_1Darray = np.array(rangeValue_1Dlist)
wValue_1Darray = np.array(wValue_1Dlist)
numFiles = numSites_1Darray.size

print "Number of Files:"
print numSites_1Darray.size
#print fileList


figNum = 0

firstGap_1Darray = np.zeros(numFiles)

for iter in range(0,numFiles):
    filename = fileList[iter]
    eigenvalue_1Darray = np.loadtxt(filename)
    
#    numSites = numSites_1Darray[iter]
#    qValue = qValue_1Darray[iter]
#    rangeValue = rangeValue_1Darray[iter]
#    wValue = wValue_1Darray[iter]

#    systemSize = numSites_1Darray[iter]
#    systemSize_1Darray = numSites*np.ones(eigenvalue_1Darray.size)

    firstGap_1Darray[iter] = eigenvalue_1Darray[-1]-eigenvalue_1Darray[-2]

#Sort data according to system size, then range, then qValue
print "Sorting Data."
data_2Darray = np.vstack((numSites_1Darray,qValue_1Darray,rangeValue_1Darray,wValue_1Darray,firstGap_1Darray))


data_2DArray_Nrq_srtd_indices = np.lexsort(np.vstack((qValue_1Darray,rangeValue_1Darray,numSites_1Darray)))

data_2DArray_Nrq_srtd = data_2Darray[:,data_2DArray_Nrq_srtd_indices]

#print data_2Darray[:,50:60]
#print data_2DArray_Nrq_srtd[:,50:60]

#Average over disorders
print "Averaging Over Disorders."
numSites_1Dlist = []
qValue_1Dlist = []
rangeValue_1Dlist = []
wValue_1Dlist = []
averageGap_1Dlist = []
averageGapSquared_1Dlist = []
counter_1Dlist = []
counter = 0
cumulativeGap = 0.
cumulativeGapSquared = 0.

for iter in range(0,numFiles):
    currentVector = data_2DArray_Nrq_srtd[0:4,iter]
    if iter == numFiles-1:
        nextVector = [0.,0.,0.,0.]
    else:
        nextVector = data_2DArray_Nrq_srtd[0:4,iter+1]
    
    counter += 1
    cumulativeGap += data_2DArray_Nrq_srtd[4,iter]
    cumulativeGapSquared += (data_2DArray_Nrq_srtd[4,iter])**2
    
    if np.any(currentVector != nextVector):
        
        averageGap = cumulativeGap / counter
        averageGapSquared = cumulativeGapSquared / counter

        numSites_1Dlist.append(data_2DArray_Nrq_srtd[0,iter])
        qValue_1Dlist.append(data_2DArray_Nrq_srtd[1,iter])
        rangeValue_1Dlist.append(data_2DArray_Nrq_srtd[2,iter])
        wValue_1Dlist.append(data_2DArray_Nrq_srtd[3,iter])
        averageGap_1Dlist.append(averageGap)
        averageGapSquared_1Dlist.append(averageGapSquared)
        counter_1Dlist.append(counter)

        counter = 0
        cumulativeGap = 0.
        cumulativeGapSquared = 0.

#    print data_2DArray_Nrq_srtd[:,iter]
#    print data_2DArray_Nrq_srtd[:,iter+1]
#    print np.any(currentVector != nextVector)
#    print cumulativeGap
#    print cumulativeGapSquared
#    print averageGap_1Dlist
#    print averageGapSquared_1Dlist
#
#    raw_input()

numSites_reduced1Darray = np.array(numSites_1Dlist)
qValue_reduced1Darray = np.array(qValue_1Dlist)
rangeValue_reduced1Darray = np.array(rangeValue_1Dlist)
wValue_reduced1Darray = np.array(wValue_1Dlist)
averageGap_reduced1Darray = np.array(averageGap_1Dlist)
averageGapSquared_reduced1Darray = np.array(averageGapSquared_1Dlist)
counter_reduced1Darray = np.array(counter_1Dlist)
stdDevGap_reduced1Darray = np.sqrt(averageGapSquared_reduced1Darray - averageGap_reduced1Darray**2)
#relStdDevGap_reduced1Darray = stdDevGap_reduced1Darray / averageGap_reduced1Darray

#print averageGap_reduced1Darray
#print relStdDevGap_reduced1Darray

#Sort data according to qValue, then range, then system size
print "Sorting Data Again."
data_reduced2Darray = np.vstack((numSites_reduced1Darray,qValue_reduced1Darray,rangeValue_reduced1Darray,wValue_reduced1Darray,averageGap_reduced1Darray,stdDevGap_reduced1Darray,counter_reduced1Darray))


data_2DArray_qrN_srtd_indices = np.lexsort(np.vstack((numSites_reduced1Darray,rangeValue_reduced1Darray,qValue_reduced1Darray)))

data_2DArray_qrN_srtd = data_reduced2Darray[:,data_2DArray_qrN_srtd_indices]

numDataPoints = numSites_reduced1Darray.size
print "Number of Data Points: "
print numDataPoints

#Get Unique QValues
uniqueQValues, sizeCounts = np.unique(qValue_reduced1Darray,return_counts=True)
numUniqueQValues = uniqueQValues.size
#print numUniqueQValues

for jiter in range(0,numUniqueQValues):
    figNum += 1
    fig = plt.figure(figNum,facecolor="white")
    ax = plt.subplot()
    
    qValue = uniqueQValues[jiter]
    print qValue
    #Get Unique alphas
#    print np.where(data_2DArray_qrN_srtd[1,:]==qValue)
    relevantIndices = np.where(data_2DArray_qrN_srtd[1,:]==qValue)
    relevantRangeValue_reduced1Darray = data_2DArray_qrN_srtd[2,:][relevantIndices]
    relevantAverageGap_reduced1Darray = data_2DArray_qrN_srtd[4,:][relevantIndices]
    relevantNumSites_reduced1Darray = data_2DArray_qrN_srtd[0,:][relevantIndices]
    relevantStdDevGap_reduced1Darray = data_2DArray_qrN_srtd[5,:][relevantIndices]
    relevantCounter_reduced1Darray = data_2DArray_qrN_srtd[6,:][relevantIndices]
#    print relevantRangeValue_reduced1Darray
    print relevantCounter_reduced1Darray

    uniqueAlphas, sizeCounts = np.unique(relevantRangeValue_reduced1Darray,return_counts=True)
    numUniqueAlphas = uniqueAlphas.size
#    print numUniqueAlphas
    #print rangeCounts
    #print uniqueRanges

    #print data_2DArray_Nr_srtd

    #Plot data for each range
    for iter in range(0,numUniqueAlphas):
        alphaValue = uniqueAlphas[iter]
        toPlot_indices = np.where(relevantRangeValue_reduced1Darray==alphaValue)
        gapToPlot_1Darray = relevantAverageGap_reduced1Darray[toPlot_indices]
        sizeToPlot_1Darray = relevantNumSites_reduced1Darray[toPlot_indices]
        CI95_1Darray = 1.96*relevantStdDevGap_reduced1Darray[toPlot_indices]/np.sqrt(relevantCounter_reduced1Darray[toPlot_indices])

        print alphaValue
        print gapToPlot_1Darray
        print sizeToPlot_1Darray
        

        labelText = r'$\alpha = {0:.2f}$'.format(alphaValue)

        ax.errorbar(sizeToPlot_1Darray,gapToPlot_1Darray,yerr=CI95_1Darray,label=labelText,marker="o",markersize=2)


    l_w = 1.5
    fs = 20
    fs2 = 20

    #line, = ax.plot([3,3],[-1E8,1E5],"r:")

    plt.xlabel(r'System Size, $N$', fontsize=fs,labelpad=10)
    plt.ylabel(r'Gap Energy $\left(\tilde t\right)$', fontsize=fs)
    fig.canvas.set_window_title("qValue = {0}".format(qValue))



    plt.yticks(fontsize=fs)
    plt.xticks(fontsize=fs)

    ax.tick_params(axis="both",width=l_w,which="both")
    ax.tick_params(axis="both",length=5,which="major")
    ax.tick_params(axis="both",length=3,which="minor")
    ##ax.yaxis.set_tick_params(width=l_w)
    ax.spines['top'].set_linewidth(l_w)
    ax.spines['bottom'].set_linewidth(l_w)
    ax.spines['left'].set_linewidth(l_w)
    ax.spines['right'].set_linewidth(l_w)

    ax.legend()
    ax.set_yscale("log", nonposx='clip')
    ax.set_xscale("log", nonposx='clip')
    #plt.ylim(0,N)
#    plt.xlim(1E-3,1E3)

    fig.tight_layout()

#figureFilename = "energyGapVsAlpha.pdf"
##fig.savefig(figureFilename, format='eps', dpi=1200)
#fig.savefig(figureFilename, format='pdf', dpi=300)


plt.show()
