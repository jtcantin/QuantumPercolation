import numpy as np
import sys
import matplotlib.pyplot as plt
import time

np.set_printoptions(threshold=100000,linewidth=2000,precision=4,suppress=False)

def EkNgammaAlphaCalc(k1,k2,k3,N,gamma,alpha):
    
    if not((np.abs(k1) <= (N-1)/2.) and (np.abs(k2) <= (N-1)/2.) and (np.abs(k3) <= (N-1)/2.)):
        sys.exit("ERROR: Need -(N-1)/2 <= k <= (N-1)/2")

    sum = 0.
    for l in np.arange(1,N,dtype=np.float_): #Up to N-1
        sum += 2.*(1-float(l)/N)*(np.cos(2.*np.pi*k1*l/N) + np.cos(2.*np.pi*k2*l/N) + np.cos(2.*np.pi*k3*l/N))/(float(l)**alpha)
    
        for m in np.arange(1,N,dtype=np.float_): #Up to N-1
            sum += 4.*(1-float(l)/N)*(1-float(m)/N)* (np.cos(2.*np.pi*k1*l/N)*np.cos(2.*np.pi*k2*m/N)+np.cos(2.*np.pi*k2*l/N)*np.cos(2.*np.pi*k3*m/N)+np.cos(2.*np.pi*k3*l/N)*np.cos(2.*np.pi*k1*m/N))/((l**2+m**2)**(alpha/2.))
            for n in np.arange(1,N,dtype=np.float_): #Up to N-1
                sum += 8.*(1-float(l)/N)*(1-float(m)/N)*(1-float(n)/N)* (np.cos(2.*np.pi*k1*l/N)*np.cos(2.*np.pi*k2*m/N)*np.cos(2.*np.pi*k3*n/N))/((l**2+m**2+n**2)**(alpha/2.))

    return sum*gamma

def EkNgammaAlphaCalc_Opt(k1,k2,k3,N,gamma,alpha):
    
    if not((np.abs(k1) <= (N-1)/2.) and (np.abs(k2) <= (N-1)/2.) and (np.abs(k3) <= (N-1)/2.)):
        sys.exit("ERROR: Need -(N-1)/2 <= k <= (N-1)/2")
    
    #l terms (single sum)
    l_1Darray = np.arange(1,N,dtype=np.float_)

    cos_l_factor_1Darray = 2.*np.pi*l_1Darray/N
    cos_k1_l_1Darray = np.cos(k1*cos_l_factor_1Darray)
    cos_k2_l_1Darray = np.cos(k2*cos_l_factor_1Darray)
    cos_k3_l_1Darray = np.cos(k3*cos_l_factor_1Darray)
    a_Nl_1Darray = 1. - l_1Darray/N
    l_denom_1Darray = np.power(l_1Darray,alpha)
    d = 1.
    
    l_terms_1Darray = a_Nl_1Darray*(cos_k1_l_1Darray+cos_k2_l_1Darray+d*cos_k3_l_1Darray)/l_denom_1Darray
    
    sum_l_terms = 2.*np.sum(l_terms_1Darray)
    
    #lm terms (double sum)
    m_1Darray = np.arange(1,N,dtype=np.float_)
    l_2Darray, m_2Darray = np.meshgrid(l_1Darray,m_1Darray)
    
    a_Nl_2Darray = 1. - l_2Darray/N
    a_Nm_2Darray = 1. - m_2Darray/N
    
    cos_l_factor_2Darray = 2.*np.pi*l_2Darray/N
    cos_m_factor_2Darray = 2.*np.pi*m_2Darray/N
    
    cos_k1_l_2Darray = np.cos(k1*cos_l_factor_2Darray)
    cos_k2_l_2Darray = np.cos(k2*cos_l_factor_2Darray)
    cos_k3_l_2Darray = np.cos(k3*cos_l_factor_2Darray)
    
    cos_k1_m_2Darray = np.cos(k1*cos_m_factor_2Darray)
    cos_k2_m_2Darray = np.cos(k2*cos_m_factor_2Darray)
    cos_k3_m_2Darray = np.cos(k3*cos_m_factor_2Darray)
    
    lm_distSqd_2Darray = l_2Darray**2+m_2Darray**2
    lm_denom_2Darray = np.power(lm_distSqd_2Darray,alpha/2.)
    
    b_ml_2Darray = 1.
    b_lm_2Darray = 1.
    
    lm_terms_2Darray = a_Nl_2Darray*a_Nm_2Darray*(cos_k1_l_2Darray*cos_k2_m_2Darray +
            b_ml_2Darray*cos_k2_l_2Darray*cos_k3_m_2Darray +
            b_lm_2Darray*cos_k3_l_2Darray*cos_k1_m_2Darray)/lm_denom_2Darray
        
    sum_lm_terms = 4.*np.sum(lm_terms_2Darray)

    #lmn terms (triple sum)
    n_1Darray = np.arange(1,N,dtype=np.float_)
    l_3Darray, m_3Darray, n_3Darray  = np.meshgrid(l_1Darray,m_1Darray,n_1Darray)

    a_Nl_3Darray = 1. - l_3Darray/N
    a_Nm_3Darray = 1. - m_3Darray/N
    a_Nn_3Darray = 1. - n_3Darray/N

    lmn_distSqd_3Darray = l_3Darray**2+m_3Darray**2+n_3Darray**2

    c_nml_3Darray = 1.

    lmn_denom_3Darray = np.power(lmn_distSqd_3Darray,alpha/2.)

    cos_l_factor_3Darray = 2.*np.pi*l_3Darray/N
    cos_m_factor_3Darray = 2.*np.pi*m_3Darray/N
    cos_n_factor_3Darray = 2.*np.pi*n_3Darray/N

    cos_k1_l_3Darray = np.cos(k1*cos_l_factor_3Darray)
    cos_k2_m_3Darray = np.cos(k2*cos_m_factor_3Darray)
    cos_k3_n_3Darray = np.cos(k3*cos_n_factor_3Darray)

    lmn_terms_3Darray = a_Nl_3Darray*a_Nm_3Darray*a_Nn_3Darray*c_nml_3Darray*cos_k1_l_3Darray*cos_k2_m_3Darray*cos_k3_n_3Darray/lmn_denom_3Darray

    sum_lmn_terms = 8.*np.sum(lmn_terms_3Darray)

    sum = 0.
    sum += sum_l_terms
    sum += sum_lm_terms
    sum += sum_lmn_terms
                                                  
    return sum*gamma


def EkNgammaAlpha_1DarrayCalc(k1,k2,k3,N,gamma,alpha_1Darray):
    EkNgammaAlpha_1Darray = np.zeros_like(alpha_1Darray)
    numk1 = alpha_1Darray.size
    print "------------------"
    for iter in range(numk1):
        
        print "{0} of {1}".format(iter+1,numk1)
        alpha = alpha_1Darray[iter]
        EkNgammaAlpha_1Darray[iter] = EkNgammaAlphaCalc_Opt(k1,k2,k3,N,gamma,alpha)
#        print EkNgammaAlpha_1Darray[iter]
#        print alpha
    return EkNgammaAlpha_1Darray

def k_basis_to_index(k1,k2,k3,N):
    shift = (N-1)/2
    k1s = k1+shift
    k2s = k2+shift
    k3s = k3+shift
    
    index = (k1s*N + k2s)*N + k3s
    
    return int(index)

def index_to_k_basis(ind,N):
    shift = (N-1)/2
    
    k3s = ind % N
    k2s = ((ind - k3s)/N) % N
    k1s = (((ind - k3s)/N) - k2s)/N
    
    return (k1s-shift,k2s-shift,k3s-shift)


#k1 = 1
#k2 = 5
#k3 = 7
#N = 31
#gamma = 1.
#alpha = 3
#
#repetitions = 10
#t_start = time.time()
#for i in range(repetitions):
#    value = EkNgammaAlphaCalc(k1,k2,k3,N,gamma,alpha)
#t_2 = time.time()
#for i in range(repetitions):
#    value2 = EkNgammaAlphaCalc_Opt(k1,k2,k3,N,gamma,alpha)
#t_3 = time.time()
#
#
#print "Time for orig calc: {0}s".format(t_2-t_start)
#print value
#print "Time for new calc: {0}s".format(t_3-t_2)
#print value2


#k1 = 0
#k2 = 0
#k3 = 0
#N = 31
#gamma = 1.
#alpha = 3
#




##Plot gap as a function of alpha and N:
#figNum = 1
#fig = plt.figure(figNum,facecolor="white")
#ax = plt.subplot()
#
#N_1Darray = np.array([11,15,21,25,31,101])
#alpha_1Darray = np.logspace(-3,3,100)
#gamma = 1
##print alpha_1Darray
#for niter in range(N_1Darray.size):
#    N = N_1Darray[niter]
#    print "N = ", N
#    print "k = 000"
#    EkNgammaAlpha_1Darray_k000 = EkNgammaAlpha_1DarrayCalc(0,0,0,N,gamma,alpha_1Darray)
#    print "k = 001"
#    print "N = ", N
#    EkNgammaAlpha_1Darray_k001 = EkNgammaAlpha_1DarrayCalc(0,0,1,N,gamma,alpha_1Darray)
#
#    gapNgamma_1Darray = EkNgammaAlpha_1Darray_k000 - EkNgammaAlpha_1Darray_k001
#    #print gapNgamma_1Darray
#
#
#
#    line = plt.plot(alpha_1Darray,gapNgamma_1Darray,linestyle="-",marker="None",label="N = {0:d}".format(N))
#
#l_w = 1.5
#fs=17
#
#plt.yticks(fontsize=fs)
#plt.xticks(fontsize=fs)
#plt.xlabel(r'$\alpha$',fontsize=fs)
#plt.ylabel(r'$\Delta_\alpha$',fontsize=fs)
##plt.ylim(0.38,0.54)
#plt.xlim(1E-3,1E3)
#plt.axvline(x=3.,color='red',ls='--',lw=l_w)
#
#ax.tick_params(axis="both",width=l_w,which="both")
#ax.tick_params(axis="both",length=5,which="major")
#ax.tick_params(axis="both",length=3,which="minor")
##ax.yaxis.set_tick_params(width=l_w)
#ax.spines['top'].set_linewidth(l_w)
#ax.spines['bottom'].set_linewidth(l_w)
#ax.spines['left'].set_linewidth(l_w)
#ax.spines['right'].set_linewidth(l_w)
#ax.set_xscale("log", nonposx='clip')
#ax.set_yscale("log", nonposy='clip')
#
#ax.legend()
#
#plt.tight_layout()
#
#figureFilename = "gapPlotVsAlpha_isotropic_analytic.eps"
##fig.savefig(figureFilename, format='eps', dpi=1200)
#fig.savefig(figureFilename, format='eps', dpi=150)
##fig.savefig(figureFilename, format='pdf', dpi=300)
#
#plt.show()

#Find gap
#Find max value
N = 11
if N % 2 != 1:
    sys.exit("ERROR: N must be odd")
gamma =1

k1_1Darray = np.arange(-(N-1)/2.,(N-1)/2.+1,dtype=np.float_)
k2_1Darray = np.arange(-(N-1)/2.,(N-1)/2.+1,dtype=np.float_)
k3_1Darray = np.arange(-(N-1)/2.,(N-1)/2.+1,dtype=np.float_)

#k1_1Darray = np.arange(-1,2)
#k2_1Darray = np.arange(-1,2)
#k3_1Darray = np.arange(-1,2)
alpha_1Darray = np.logspace(-3,3,10)#np.array([3])#np.logspace(-3,3,10)

numk1 = k1_1Darray.size
numk2 = k2_1Darray.size
numk3 = k3_1Darray.size

gap_1Darray = np.zeros(alpha_1Darray.size)

index_1Darray = np.arange(numk1*numk2*numk3)

print k_basis_to_index(-(N-1)/2.,-(N-1)/2.,-(N-1)/2.,N)

for aiter in range(alpha_1Darray.size):
    print "------------------------------"
    EkNgammaAlpha_3Darray_flattened = np.zeros_like(index_1Darray,dtype=np.float_)
    count = 0
    alpha = alpha_1Darray[aiter]
    for iter in range(numk1):
        print "{0} of {1}".format(count,numk1*numk2*numk3)
        for jiter in range(numk2):
            for kiter in range(numk3):
                count+=1

                k1 = k1_1Darray[iter]
                k2 = k2_1Darray[jiter]
                k3 = k3_1Darray[kiter]
                index = k_basis_to_index(k1,k2,k3,N)

                EkNgammaAlpha_3Darray_flattened[index] = EkNgammaAlphaCalc_Opt(k1,k2,k3,N,gamma,alpha)

    EkNgammaAlpha_3Darray_flattened_sortedIndices = np.argsort(EkNgammaAlpha_3Darray_flattened)

#    print EkNgammaAlpha_3Darray_flattened
#    print EkNgammaAlpha_3Darray_flattened_sortedIndices
    print EkNgammaAlpha_3Darray_flattened[EkNgammaAlpha_3Darray_flattened_sortedIndices][-20:]
#    print index_to_k_basis(EkNgammaAlpha_3Darray_flattened_sortedIndices[-20:],N)

    gap_1Darray[aiter] = EkNgammaAlpha_3Darray_flattened[EkNgammaAlpha_3Darray_flattened_sortedIndices][-1] - EkNgammaAlpha_3Darray_flattened[EkNgammaAlpha_3Darray_flattened_sortedIndices][-2]
    print "Largest Eigval:"
    print index_to_k_basis(EkNgammaAlpha_3Darray_flattened_sortedIndices[-1],N)
    print "2nd Largest Eigval:"
    print index_to_k_basis(EkNgammaAlpha_3Darray_flattened_sortedIndices[-2],N)

figNum = 1
fig = plt.figure(figNum,facecolor="white")
ax = plt.subplot()

line = plt.plot(alpha_1Darray,gap_1Darray,linestyle="-",marker=".")

l_w = 1.5
fs=17

plt.yticks(fontsize=fs)
plt.xticks(fontsize=fs)
plt.xlabel(r'$\alpha$',fontsize=fs)
plt.ylabel(r'$Gap Energy (\tilde t)$',fontsize=fs)
#plt.ylim(0.38,0.54)

ax.tick_params(axis="both",width=l_w,which="both")
ax.tick_params(axis="both",length=5,which="major")
ax.tick_params(axis="both",length=3,which="minor")
#ax.yaxis.set_tick_params(width=l_w)
ax.spines['top'].set_linewidth(l_w)
ax.spines['bottom'].set_linewidth(l_w)
ax.spines['left'].set_linewidth(l_w)
ax.spines['right'].set_linewidth(l_w)
ax.set_yscale("log", nonposx='clip')
ax.set_xscale("log", nonposx='clip')

plt.show()



#EkNgammaAlpha = EkNgammaAlphaCalc(k1,k2,k3,N,gamma,alpha)
#print EkNgammaAlpha

#Find gap -> between k=[0,0,0] and k=[1,0,0] (6 degenerate states)
#Find max value
#k1_1Darray = np.arange(-(N-1)/2.,(N-1)/2.+1)
#k2_1Darray = np.arange(-(N-1)/2.,(N-1)/2.+1)
#k3_1Darray = np.arange(-(N-1)/2.,(N-1)/2.+1)

#k1_1Darray = np.arange(-1,2)
#k2_1Darray = np.arange(-1,2)
#k3_1Darray = np.arange(-1,2)
#alpha_1Darray = np.logspace(-3,3,10)
#
#numk1 = k1_1Darray.size
#numk2 = k2_1Darray.size
#numk3 = k3_1Darray.size
#
#for aiter in range(alpha_1Darray.size):
#    print "------------------------------"
#    EkNgammaAlpha_3Darray = np.zeros((numk1,numk2,numk3))
#    count = 0
#    alpha = alpha_1Darray[aiter]
#    for iter in range(numk1):
#        for jiter in range(numk2):
#            for kiter in range(numk3):
#                count+=1
##                print "{0} of {1}".format(count,numk1*numk2*numk3)
#                k1 = k1_1Darray[iter]
#                k2 = k2_1Darray[jiter]
#                k3 = k3_1Darray[kiter]
#                EkNgammaAlpha_3Darray[iter,jiter,kiter] = EkNgammaAlphaCalc(k1,k2,k3,N,gamma,alpha)
#
#    print EkNgammaAlpha_3Darray
##plot as a function of k1
#k1_1Darray = np.arange(-(N-1)/2.,(N-1)/2.+1) # -(N-1)/2. to (N-1)/2.
#EkNgammaAlpha_1Darray = np.zeros_like(k1_1Darray)
#
#numk1 = k1_1Darray.size
#for iter in range(numk1):
#    print "{0} of {1}".format(iter+1,numk1)
#    k1 = k1_1Darray[iter]
#    EkNgammaAlpha_1Darray[iter] = EkNgammaAlphaCalc(k1,k2,k3,N,gamma,alpha)
#
#figNum = 1
#fig = plt.figure(figNum,facecolor="white")
#ax = plt.subplot()
#
#line = plt.plot(k1_1Darray,EkNgammaAlpha_1Darray,linestyle="None",marker=".")
#
#l_w = 1.5
#fs=17
#
#plt.yticks(fontsize=fs)
#plt.xticks(fontsize=fs)
#plt.xlabel(r'$k_1$',fontsize=fs)
#plt.ylabel(r'$E_{{k_1,{0},{1}}}$'.format(k2,k3),fontsize=fs)
##plt.ylim(0.38,0.54)
#
#ax.tick_params(axis="both",width=l_w,which="both")
#ax.tick_params(axis="both",length=5,which="major")
#ax.tick_params(axis="both",length=3,which="minor")
##ax.yaxis.set_tick_params(width=l_w)
#ax.spines['top'].set_linewidth(l_w)
#ax.spines['bottom'].set_linewidth(l_w)
#ax.spines['left'].set_linewidth(l_w)
#ax.spines['right'].set_linewidth(l_w)
#
##ax.legend()
#
#plt.tight_layout()
#
#plt.show()














