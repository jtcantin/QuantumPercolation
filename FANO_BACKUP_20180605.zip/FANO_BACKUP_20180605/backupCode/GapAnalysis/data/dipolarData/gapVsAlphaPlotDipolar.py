import matplotlib.pyplot as plt
import numpy as np
import sys
from os import listdir
from os.path import isfile, join, isdir

np.set_printoptions(threshold=10000,linewidth=2000,precision=4,suppress=False)

dirToUse = sys.argv[1]
#Find all relevant directories
dirList = [ join(dirToUse,dir) for dir in listdir(dirToUse) if (isdir(join(dirToUse,dir)) and "data" in dir) ]
numDir = len(dirList)

numSites_1Darray = np.zeros(numDir,dtype=np.int_)
qValue_1Darray = np.zeros(numDir,dtype=np.int_)
rangeValue_1Darray = np.zeros(numDir)
wValue_1Darray = np.zeros(numDir)
fileList = []

print "Num Directories: ", numDir

for iter in range(0,numDir):
    print "Getting files from directory {0} of {1}".format(iter+1,numDir)
    directory = dirList[iter]

    dirFiles = [ f for f in listdir(directory) if (isfile(join(directory,f)) and f!="._.DS_Store" and f!=".DS_Store") ]

    inputFilename = [x for x in dirFiles if "dis_in" in x.split("/")[-1]][0]
    inputFile = open(join(directory,inputFilename),'r')
    fileLines = inputFile.readlines()

    numSites = int(fileLines[1])
    qValue = int(fileLines[9])
    rangeValue = float(fileLines[5])
    wValue = float(inputFilename.split("_")[4][1:])

    numSites_1Darray[iter] = numSites
    qValue_1Darray[iter] = qValue
    rangeValue_1Darray[iter] = rangeValue
    wValue_1Darray[iter] = wValue
    
    dataFilename = [x for x in dirFiles if "Eval" in x.split("/")[-1]][0]
    fileList.append(join(directory,dataFilename))

#    print numSites
#    print qValue
#    print range
#    print wValue



figNum = 0
figNum += 1
fig = plt.figure(figNum,facecolor="white")
ax = plt.subplot()
firstGap_1Darray = np.zeros(numDir)
color_1Darray = ["c","orange","r","purple","b","k"]

for iter in range(0,numDir):
    print "Getting data from directory {0} of {1}".format(iter+1,numDir)
    filename = fileList[iter]
    eigenvalue_1Darray = np.loadtxt(filename)
    
#    numSites = numSites_1Darray[iter]
#    qValue = qValue_1Darray[iter]
#    rangeValue = rangeValue_1Darray[iter]
#    wValue = wValue_1Darray[iter]

#    systemSize = numSites_1Darray[iter]
#    systemSize_1Darray = numSites*np.ones(eigenvalue_1Darray.size)

    firstGap_1Darray[iter] = eigenvalue_1Darray[-1]-eigenvalue_1Darray[-2]
    # firstGap_1Darray[iter] = eigenvalue_1Darray[1]-eigenvalue_1Darray[0]

#Sort data according to system size, then range
data_2Darray = np.vstack((numSites_1Darray,qValue_1Darray,rangeValue_1Darray,wValue_1Darray,firstGap_1Darray))

data_2DArray_Nr_srtd_indices = np.lexsort(np.vstack((rangeValue_1Darray,numSites_1Darray)))

data_2DArray_Nr_srtd = data_2Darray[:,data_2DArray_Nr_srtd_indices]

print "Sorting completed."

#Get Unique sizes
uniqueSizes, sizeCounts = np.unique(numSites_1Darray,return_counts=True)
numUniqueSizes = uniqueSizes.size
#print rangeCounts
#print uniqueRanges

#print data_2DArray_Nr_srtd

#Plot data for each range
print "Plotting Data."
for iter in range(0,numUniqueSizes):
    sizeValue = uniqueSizes[iter]
    toPlot_indices = np.where(data_2DArray_Nr_srtd[0]==sizeValue)
    gapToPlot_1Darray = data_2DArray_Nr_srtd[4][toPlot_indices]
    rangeToPlot_1Darray = data_2DArray_Nr_srtd[2][toPlot_indices]

    print sizeValue
    print gapToPlot_1Darray
    print rangeToPlot_1Darray
    
    labelText = r'$N = {0:d}$'.format(sizeValue)

    line, = ax.plot(rangeToPlot_1Darray,gapToPlot_1Darray,label=labelText,marker="None",markersize=2,color=color_1Darray[iter])#marker="o",markersize=2


l_w = 1.5
fs = 20
fs2 = 20



#fig.canvas.set_window_title("EigenvalueGapPlot")



plt.yticks(fontsize=fs)
plt.xticks(fontsize=fs)
plt.xlabel(r'Hopping Parameter Exponent, $\alpha$', fontsize=fs,labelpad=10)
plt.ylabel(r'Gap Energy $\left(\tilde t\right)$', fontsize=fs)

plt.axvline(x=3.,color='red',ls='--',lw=l_w)

ax.tick_params(axis="both",width=l_w,which="both")
ax.tick_params(axis="y",width=l_w-0.5,which="minor")
ax.spines['top'].set_linewidth(l_w)
ax.spines['bottom'].set_linewidth(l_w)
ax.spines['left'].set_linewidth(l_w)
ax.spines['right'].set_linewidth(l_w)

#Zoomed Version
plt.ylim(1E-5,1E2)
plt.text(3., 1, r'$\leftarrow\alpha=3$', fontsize=fs,color="k")#3.025
plt.text(2.57, 3E1, "Anisotropic, 3D", fontsize=fs,color="k")
plt.text(3.25, 2E-5, "(D)", fontsize=fs,color="k")

ax.tick_params(axis="x",length=5,which="major")
ax.tick_params(axis="x",length=3,which="minor")
ax.tick_params(axis="y",length=7,which="major")
ax.tick_params(axis="y",length=4,which="minor")
##ax.yaxis.set_tick_params(width=l_w)


#plt.xlim(1E-5,1E3)
xMin = 1.5
xMax = 3.5
plt.xlim(xMin,xMax)#(1E-3,1E3)
ax.set_yscale("log", nonposx='clip')
#ax.set_xscale("log", nonposx='clip')
plt.xticks(np.arange(xMin, xMax+0.5, 0.5))

ax.legend(loc="lower left",fontsize=fs-6)#fs-6,fs-10

plt.tight_layout()

figureFilename = "energyGapVsAlphaDipolarZoomed.eps"
#fig.savefig(figureFilename, format='eps', dpi=1200)
fig.savefig(figureFilename, format='eps', dpi=300)
# fig.savefig(figureFilename, format='jpeg', dpi=600)

#Full Version
plt.ylim(2E-5,1E4)

ax.tick_params(axis="x",length=7,which="major")
ax.tick_params(axis="x",length=4,which="minor")
ax.tick_params(axis="y",length=7,which="major")
ax.tick_params(axis="y",length=4,which="minor")
##ax.yaxis.set_tick_params(width=l_w)


#plt.xlim(1E-5,1E3)
xMin = 3E-2
xMax = 3E1
plt.xlim(xMin,xMax)#(1E-3,1E3)
ax.set_yscale("log", nonposx='clip')
ax.set_xscale("log", nonposx='clip')
#plt.xticks(np.arange(xMin, xMax+0.5, 0.5))

ax.texts[-3].set_position((3,3))
ax.texts[-2].set_position((1.3,2E3))#(1.5,2E3))
ax.texts[-1].set_position((15,8E-5))#(2E2,8E-5))
ax.texts[-1].set_text("(C)")

#ax.legend(loc="lower left",fontsize=fs-10)

plt.tight_layout()

figureFilename = "energyGapVsAlphaDipolar.eps"
#fig.savefig(figureFilename, format='eps', dpi=1200)
fig.savefig(figureFilename, format='eps', dpi=300)
# fig.savefig(figureFilename, format='jpeg', dpi=600)


plt.show()
