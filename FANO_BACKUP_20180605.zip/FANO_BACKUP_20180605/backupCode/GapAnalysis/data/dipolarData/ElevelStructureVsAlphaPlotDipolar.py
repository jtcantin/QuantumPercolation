import matplotlib
# matplotlib.use("agg")
import matplotlib.pyplot as plt
import numpy as np
import sys
from os import listdir
from os.path import isfile, join

np.set_printoptions(threshold=10000,linewidth=2000,precision=4,suppress=False)

dirList = sys.argv[1:]
numDir = len(dirList)

numSites_1Darray = np.zeros(numDir,dtype=np.int_)
qValue_1Darray = np.zeros(numDir,dtype=np.int_)
rangeValue_1Darray = np.zeros(numDir)
wValue_1Darray = np.zeros(numDir)
fileList = []

print "Num Directories: ", numDir

for iter in range(0,numDir):
    print "Getting files from directory {0} of {1}".format(iter+1,numDir)
    directory = dirList[iter]

    dirFiles = [ f for f in listdir(directory) if (isfile(join(directory,f)) and f!="._.DS_Store" and f!=".DS_Store") ]

    inputFilename = [x for x in dirFiles if "dis_in" in x.split("/")[-1]][0]
    inputFile = open(join(directory,inputFilename),'r')
    fileLines = inputFile.readlines()

    numSites = int(fileLines[1])
    qValue = int(fileLines[9])
    rangeValue = float(fileLines[5])
    wValue = float(inputFilename.split("_")[4][1:])

    numSites_1Darray[iter] = numSites
    qValue_1Darray[iter] = qValue
    rangeValue_1Darray[iter] = rangeValue
    wValue_1Darray[iter] = wValue
    
    dataFilename = [x for x in dirFiles if "Eval" in x.split("/")[-1]][0]
    fileList.append(join(directory,dataFilename))

#    print numSites
#    print qValue
#    print range
#    print wValue



figNum = 0
figNum += 1
fig = plt.figure(figNum,facecolor="white")
ax = plt.subplot()
firstGap_1Darray = np.zeros(numDir)
numStates = 5 #1,1,1,2
statesToPlot_2Darray = np.zeros((numDir,numStates))
linecolor_1Darray = ['k','k','k','k','k',"orange","orange","g","r","c"]#"b","orange","yellow",'c','r','r','r',"purple"]
linestyle_1Darray = ["None","None","None","None","None","--","--",":","-.","-"]#":",":",":","-.","--","--","--","-"]

for iter in range(0,numDir):
    print "Getting data from directory {0} of {1}".format(iter+1,numDir)
    filename = fileList[iter]
    eigenvalue_1Darray = np.loadtxt(filename)
    
#    numSites = numSites_1Darray[iter]
#    qValue = qValue_1Darray[iter]
#    rangeValue = rangeValue_1Darray[iter]
#    wValue = wValue_1Darray[iter]

#    systemSize = numSites_1Darray[iter]
#    systemSize_1Darray = numSites*np.ones(eigenvalue_1Darray.size)

    firstGap_1Darray[iter] = eigenvalue_1Darray[-1]-eigenvalue_1Darray[-2]
    # firstGap_1Darray[iter] = eigenvalue_1Darray[1]-eigenvalue_1Darray[0]
    statesToPlot_2Darray[iter,:] = eigenvalue_1Darray[-numStates:]
#    print statesToPlot_2Darray[iter,:]
    print "Alpha = ", rangeValue_1Darray[iter]
    print eigenvalue_1Darray[-10:]

#Sort data according to system size, then range
data_2Darray = np.vstack((numSites_1Darray,qValue_1Darray,rangeValue_1Darray,wValue_1Darray,firstGap_1Darray,statesToPlot_2Darray.T))

print data_2Darray.shape

data_2DArray_Nr_srtd_indices = np.lexsort(np.vstack((rangeValue_1Darray,numSites_1Darray)))

data_2DArray_Nr_srtd = data_2Darray[:,data_2DArray_Nr_srtd_indices]

print "Sorting completed."

#Get Unique sizes
uniqueSizes, sizeCounts = np.unique(numSites_1Darray,return_counts=True)
numUniqueSizes = uniqueSizes.size
#print rangeCounts
#print uniqueRanges

#print data_2DArray_Nr_srtd

#Plot data for each range
print "Plotting Data."
for iter in range(0,numUniqueSizes):
    sizeValue = uniqueSizes[iter]
    toPlot_indices = np.where(data_2DArray_Nr_srtd[0]==sizeValue)
    gapToPlot_1Darray = data_2DArray_Nr_srtd[4][toPlot_indices]
    rangeToPlot_1Darray = data_2DArray_Nr_srtd[2][toPlot_indices]

    print sizeValue
    print gapToPlot_1Darray
    print rangeToPlot_1Darray
    
    labelText = r'$N = {0:.1f}$'.format(sizeValue)

    # line, = ax.plot(rangeToPlot_1Darray,gapToPlot_1Darray,label=labelText,marker="o",markersize=2)#marker="o",markersize=2
    for jiter in range(5,5+numStates):
        line, = ax.plot(rangeToPlot_1Darray,data_2DArray_Nr_srtd[jiter][toPlot_indices],label=labelText,marker="None",markersize=2,color=linecolor_1Darray[jiter],linestyle=linestyle_1Darray[jiter])

l_w = 1.5
fs = 20
fs2 = 20

line, = ax.plot([3,3],[-1E8,1E10],"r:")
ax.arrow(1E-2, 600, 0, 1.9E3-600-600, head_width=3.5E-3, head_length=600, fc='k', ec='k', width=0.2E-3)
plt.text(2.5E-3, 310, r"Doublet", fontsize=fs-3,color="k")
plt.text(3., 200, r'$\leftarrow\alpha=3$', fontsize=fs,color="k")

plt.xlabel(r'Hopping Parameter Exponent, $\alpha$', fontsize=fs,labelpad=10)
plt.ylabel(r'Energy $\left(\tilde t\right)$', fontsize=fs)
fig.canvas.set_window_title("EigenvalueGapPlot")



plt.yticks(fontsize=fs)
plt.xticks(fontsize=fs)

ax.tick_params(axis="both",width=l_w,which="both")
ax.tick_params(axis="both",length=7,which="major")
ax.tick_params(axis="both",length=4,which="minor")
##ax.yaxis.set_tick_params(width=l_w)
ax.spines['top'].set_linewidth(l_w)
ax.spines['bottom'].set_linewidth(l_w)
ax.spines['left'].set_linewidth(l_w)
ax.spines['right'].set_linewidth(l_w)

# ax.legend()
ax.set_yscale("log", nonposx='clip')
ax.set_xscale("log", nonposx='clip')
# plt.ylim(5,2E4)
plt.ylim(0.8,3E4)
plt.xlim(1E-3,1E3)
# plt.xlim(1.75,5)#(1E-3,1E3)
plt.text(2.05, 1.3E4, "Anisotropic, 3D", fontsize=fs,color="k")

fig.tight_layout()

figureFilename = "energyLevelsVsAlphaDipolar.eps"
#fig.savefig(figureFilename, format='eps', dpi=1200)
fig.savefig(figureFilename, format='eps', dpi=300)
# fig.savefig(figureFilename, format='jpeg', dpi=600)


plt.show()
