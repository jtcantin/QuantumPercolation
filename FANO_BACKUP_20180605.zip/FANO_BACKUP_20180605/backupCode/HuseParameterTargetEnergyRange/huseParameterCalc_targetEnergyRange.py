import numpy as np
import sys
from os import listdir
from os.path import isfile, isdir, join

np.set_printoptions(threshold=100000,linewidth=20000,precision=4,suppress=False)

topLevelDataDir = sys.argv[1]
ErangeMin = float(sys.argv[2])
ErangeMax = float(sys.argv[3])

#Go through data directories one at a time, adding to dictionary
#Use a dictionary to allow for multiple directories having the same N,q,w

dataDir_list = [ f for f in listdir(topLevelDataDir) if (isdir(join(topLevelDataDir,f)) and f!="._.DS_Store" and f!=".DS_Store") ]

huseParamDict = {} #Keys: N???_q??_w???, Values: [sum,sqSum,count]
blankDataArray = np.zeros(3)
numDir = len(dataDir_list)

for iter in range(numDir):
    dataDir = dataDir_list[iter]

    dictKey = dataDir[5:20]
    
    dataDirPath = join(topLevelDataDir,dataDir)
    eigenvalueFile_list = [ f for f in listdir(dataDirPath) if (isfile(join(dataDirPath,f)) and f!="._.DS_Store" and f!=".DS_Store") and f.endswith("_Eval.txt")]

    numFile = len(eigenvalueFile_list)

    for jiter in range(numFile):
        
    
        eigVals_1DarrayTemp = np.loadtxt(join(dataDirPath,eigenvalueFile_list[jiter]))
        eigVals_1Darray = np.sort(eigVals_1DarrayTemp)
        print eigVals_1Darray.shape
        
        #Select out a particular energy range
        siftingArray_indices = np.logical_and(eigVals_1Darray >= ErangeMin, eigVals_1Darray <= ErangeMax)
        
#        invertd_eigVals_1Darray = eigVals_1Darray[np.invert(siftingArray_indices)]
#        lower_eigVals_1Darray = eigVals_1Darray[np.logical_and(np.invert(siftingArray_indices),eigVals_1Darray < 0)]
#        upper_eigVals_1Darray = eigVals_1Darray[np.logical_and(np.invert(siftingArray_indices),eigVals_1Darray > 0)]

        eigVals_1Darray = eigVals_1Darray[siftingArray_indices]
        
        print "Sorted array:"
        print eigVals_1Darray.shape
        print np.amin(eigVals_1Darray)
        print np.amax(eigVals_1Darray)
#        print invertd_eigVals_1Darray.shape
#        print invertd_eigVals_1Darray.size + eigVals_1Darray.size
#        print np.amin(upper_eigVals_1Darray)
#        print np.amax(lower_eigVals_1Darray)
#        print upper_eigVals_1Darray.size + lower_eigVals_1Darray.size

#        raw_input()

        diffEigVals_1Darray = np.diff(eigVals_1Darray)
        compare_2Darray = np.vstack((diffEigVals_1Darray,np.roll(diffEigVals_1Darray,1)))[:,1:]
        ratio_1Darray = np.min(compare_2Darray,axis=0)/np.max(compare_2Darray,axis=0)
#        print eigVals_1Darray[:10]
#        print (np.roll(eigVals_1Darray,-1)-eigVals_1Darray)[:10]
#        print diffEigVals_1Darray[:10]
#        print compare_2Darray[:,:10]
#        print "Min, then max: "
#        print np.min(compare_2Darray,axis=0)[:10]
#        print np.max(compare_2Darray,axis=0)[:10]
#        print ratio_1Darray[:10]
#
#        raw_input()

        
        huseParam = np.mean(ratio_1Darray)
        print "Dir {0} of {1}".format(iter+1,numDir)
        print "File {0} of {1}".format(jiter+1,numFile)
        print dictKey
        print huseParam

        huseParamDict[dictKey] = huseParamDict.get(dictKey, blankDataArray) + np.array([huseParam,huseParam**2,1])

#        print huseParamDict
        print "-----------------------"

#Convert Dict to numpy arrays
numParameterSets = len(huseParamDict)

data_2Darray = np.empty((9,numParameterSets))

count = 0
for iter, iterVal in huseParamDict.items():
    
    N_val = int(iter[1:4])
    q_val = float(iter[6:8])/100
    w_val = float(iter[10:15].strip("_r"))
    
    sumHparam = iterVal[0]
    sqSumHparam = iterVal[1]
    numDis = iterVal[2]
    
    
    
#    print sqSumHparam
    var = (sqSumHparam - sumHparam*sumHparam/numDis)/(numDis-1)
    kappaEstimate = sqSumHparam / np.sqrt(var)
    varErrorEstimate = kappaEstimate*kappaEstimate*numDis*np.finfo(np.float_).eps
    
#    print var
#    print kappaEstimate
#    print "Variance Error Upper Bound Estimate (textbook algorithm):"
#    print varErrorEstimate
#    print "--------"

    data_2Darray[:,count] = np.array([N_val,q_val,w_val,sumHparam/numDis,sqSumHparam,var,kappaEstimate,varErrorEstimate,numDis])

    count += 1

print "Max Variance Dev Relative Error Upper Bound Estimate (textbook algorithm):"
print np.nanmax(data_2Darray[7,:])
print "Min:"
print np.nanmin(data_2Darray[7,:])

headerString = "N \t q \t w \t Huse Parameter Avg \t Huse Parameter Squared Sum \t Sample Variance (Textbook Algorithm) \t kappa Estimate \t Variance Relative Error Upper Bound Estimate \t Num Disorders"

np.savetxt("huseParamProcessedData_isotropic_temp_range{0:.3E}_{1:.3E}.txt".format(ErangeMin,ErangeMax),data_2Darray.T,header=headerString,fmt="%.15e")























