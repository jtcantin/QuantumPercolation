import numpy as np
import numpy.random
import matplotlib
#matplotlib.use('agg')
import matplotlib.pyplot as plt
import sys
from os import listdir
from os.path import isfile, join, isdir
import scipy.stats
from matplotlib.ticker import Locator
from matplotlib.ticker import AutoMinorLocator

np.set_printoptions(threshold=10000,linewidth=2000,precision=4,suppress=False)

def floatEqual(a,b):
    if np.abs((a-b)/np.minimum(a,b)) < 1E-13:
        return True
    else:
        return False

#From https://stackoverflow.com/questions/44970010/axes-class-set-explicitly-size-width-height-of-axes-in-given-units
def set_size(w,h, ax=None,dpi_man=150):
    """ w, h: width, height in inches """
    if not ax: ax=plt.gca()
    l = ax.figure.subplotpars.left
    r = ax.figure.subplotpars.right
    t = ax.figure.subplotpars.top
    b = ax.figure.subplotpars.bottom
    figw = float(w)/(r-l)
    figh = float(h)/(t-b)
    ax.figure.set_size_inches(figw, figh)#,dpi=dpi_man)

class MinorSymLogLocator(Locator):
    """
        Dynamically find minor tick positions based on the positions of
        major ticks for a symlog scaling.
        """
    def __init__(self, linthresh, nints=10):
        """
            Ticks will be placed between the major ticks.
            The placement is linear for x between -linthresh and linthresh,
            otherwise its logarithmically. nints gives the number of
            intervals that will be bounded by the minor ticks.
            """
        self.linthresh = linthresh
        self.nintervals = nints
    
    def __call__(self):
        # Return the locations of the ticks
        majorlocs = self.axis.get_majorticklocs()
        
        if len(majorlocs) == 1:
            return self.raise_if_exceeds(np.array([]))
    
        # add temporary major tick locs at either end of the current range
        # to fill in minor tick gaps
        dmlower = majorlocs[1] - majorlocs[0]    # major tick difference at lower end
        dmupper = majorlocs[-1] - majorlocs[-2]  # major tick difference at upper end
        
        # add temporary major tick location at the upper end
        if majorlocs[0] != 0. and ((majorlocs[0] != self.linthresh and dmlower > self.linthresh) or (dmlower == self.linthresh and majorlocs[0] < 0)):
            majorlocs = np.insert(majorlocs, 0, majorlocs[0]*10.)
        else:
            majorlocs = np.insert(majorlocs, 0, majorlocs[0]-self.linthresh)
        
        # add temporary major tick location at the upper end
        if majorlocs[-1] != 0. and ((np.abs(majorlocs[-1]) != self.linthresh and dmupper > self.linthresh) or (dmupper == self.linthresh and majorlocs[-1] > 0)):
            majorlocs = np.append(majorlocs, majorlocs[-1]*10.)
        else:
            majorlocs = np.append(majorlocs, majorlocs[-1]+self.linthresh)

        # iterate through minor locs
        minorlocs = []
        
        # handle the lowest part
        for i in xrange(1, len(majorlocs)):
            majorstep = majorlocs[i] - majorlocs[i-1]
            if abs(majorlocs[i-1] + majorstep/2) < self.linthresh:
                ndivs = self.nintervals
            else:
                ndivs = self.nintervals - 1.
            
            minorstep = majorstep / ndivs
            locs = np.arange(majorlocs[i-1], majorlocs[i], minorstep)[1:]
            minorlocs.extend(locs)
        
        return self.raise_if_exceeds(np.array(minorlocs))

    def tick_values(self, vmin, vmax):
        raise NotImplementedError('Cannot get tick locations for a '
                              '%s type.' % type(self))


firstInput = sys.argv[1]

if isdir(firstInput):
    dataDir = firstInput


    dataSubDirList = [dir for dir in listdir(dataDir) if (isdir(join(dataDir,dir)))]
    numDir = len(dataSubDirList)

    data2DList = []

    for dirNum in range(0,numDir):
        currentDataDir = dataSubDirList[dirNum]
        parameterList = currentDataDir.split("_")
        print "Directory {0} of {1} ".format(dirNum+1,numDir)
        print currentDataDir

        size = int(parameterList[1].strip("N"))
        pVal = 1. - float(parameterList[2].strip("q"))/100.
        wVal = float(parameterList[3].strip("w"))
        rangeExp = 100000. if parameterList[4].strip("r-") == "TB" else float(parameterList[4].strip("r-"))
        hopType = (1 if parameterList[5] == "anisotropic" else 0)#0 means isotropic, 1 means anisotropic
    #    print size
    #    print pVal
    #    print wVal
    #    print rangeExp
    #    print hopType

        datafileList = [f for f in listdir(join(dataDir,currentDataDir)) if (isfile(join(dataDir,currentDataDir,f))) and ("IPR.txt" in f)]
        numDatafiles = len(datafileList)
    #    print numDatafiles

        for datafileNum in range(0,numDatafiles):
            datafile = join(dataDir,currentDataDir,datafileList[datafileNum])
            disNum = int(datafileList[datafileNum].split("_")[3])
            energyIPR_2Darray = np.loadtxt(datafile)
            
            print "{0} of {1}".format(datafileNum+1,numDatafiles)
            for iter in range(0,energyIPR_2Darray.shape[0]):
                appendList = [size, pVal, wVal, rangeExp, hopType, disNum, energyIPR_2Darray[iter,0], energyIPR_2Darray[iter,1]]
                data2DList.append(appendList)
    #    print datafileList

    #Convert IPR to PR
    data2Darray = np.array(data2DList)
    data2Darray[:,-1] = 1./data2Darray[:,-1]
    
    print "Saving collected data."
    totalDatafilename = str(dataDir.split("/")[-2])+"_collected.npy"#.txt"
#    np.savetxt(totalDatafilename, data2Darray, header=" 0     1      2       3        4        5       6    7 \nsize, pVal, wVal, rangeExp, hopType, disNum, energy, PR")
    np.save(totalDatafilename,data2Darray)
    print "Data saved to: ", totalDatafilename
    
    uniqueSizes, uniqueSizesIndices = np.unique(data2Darray[:,0], return_index=True)
    for iter in range(0,uniqueSizes.size):
        N = uniqueSizes[iter]
        
        for hopTypeParam in [0,1]:
            newData2DArray_indices = np.logical_and(data2Darray[:,4].astype(np.int_)==hopTypeParam,data2Darray[:,0].astype(np.int_)==N)
            newData2DArray = data2Darray[newData2DArray_indices,:]
            disNums_1Darray = newData2DArray[:,5]
            print "N: {0} Hop: {1} DisCount: {2} MaxDisNum: {3} ".format(N,hopTypeParam,disNums_1Darray.size/(N**3),np.amax(disNums_1Darray))
                                                                     
#    uniqueVals, uniqueIndices = np.unique(data2Darray[:,5], return_index=True)
#    print "Unique Numbers of Disorder: ", uniqueVals
#    print "Corresponding System Size: ", data2Darray[uniqueIndices,0]
#    print "Corresponding Hopping Types: ", data2Darray[uniqueIndices,4]

elif isfile(firstInput):
    print "Loading data from: ", firstInput
#    data2Darray = np.loadtxt(firstInput)
    data2Darray = np.load(firstInput)
    print "Data loaded."
    print "data2Darray.shape: ", data2Darray.shape
    #data2Darray columns:
    # 0     1      2       3        4        5       6    7
    #size, pVal, wVal, rangeExp, hopType, disNum, energy, PR

    #print data2Darray[12654:12674,:]
    
    #Get bandwidths for systems
    secondInput = sys.argv[2]
    print "Loading data from: ", secondInput
    #    data2Darray = np.loadtxt(secondInput)
    bandwidthData2Darray = np.load(secondInput)
    print "Data loaded."
    print "bandwidthData2Darray.shape: ", bandwidthData2Darray.shape
    
    
    figNum = 0
    figNum += 1
    fig = plt.figure(figNum,facecolor="white")
    ax = plt.subplot()
    ###########################################################
    ###################Parameters##############################
    sizeArray = np.array([31,21,11])
    sizeMarkerColor_array = np.array(["#1f77b4","#ff7f0e","#2ca02c"])
    markerStyle_array = ["s","D","."]
    markerColor_array = ["k","r","g"]
    markerSize_array = [5,4,8]
    
    hopTypeString = "isotropic" #"anisotropic", "isotropic"
    plotType = "raw" #"raw","average","median","eigstateAvg"
    
    binDensity = 9#6#9 #per order of magnitude
    linBinWidth = 0.05#0.05#0.5
    linearPortionHalfWidth = 16#40#16.5#10#35#50
    binType = "loglin" #loglin,log,linear
    examineEnergy_1Darray = []#[-1E5,-1,0,1E5] #np.linspace(-350,700,100)#np.linspace(-16.5,16.5,50)#[-5E5,-1E-3,1E-3,5E5]#[-200,-1E-3,1E-3,200]#200 for the highest energy
    #    examineBin_1Darray = [85,-1]#75,60
    bandwidthOverride = "Y"
    manualUpperBoundFlag = "Y"
    manualUpperBound = 100
    xLimL = -1E3
    xLimU = 1E3
    xTicksArrayFlag = "N"
    xTicksArray = [-10,0,10,1E2,1E3] if hopTypeString == "isotropic" else [-1E3,-1E2,-16,0,16,1E2,1E3]#[-1E3,-1E2,-1E1,0,10,1E2,1E3]
    xTicksLabels = [r'-$10$',r'$0$',r'$10$',r'$10^2$',r'$10^3$'] if hopTypeString == "isotropic" else [r'-$10^3$',r'-$10^2$',r'-$16$',r'$0$',r'$16$',r'$10^2$',r'$10^3$']
    halveDisorders = "N" #Y/N
    linearScale = "Y"
    PR_Div_NCubed = "Y"
    invertOrder = "N"
    #########################################################
    sizeArray = sizeArray[::-1] if invertOrder == "Y" else sizeArray
    sizeMarkerColor_array = sizeMarkerColor_array[::-1] if invertOrder == "Y" else sizeMarkerColor_array
    
    if hopTypeString == "anisotropic":
        drawLines = "Y"
    else:
        drawLines = "N"
    
    
    observableN_2Darray = np.zeros((len(examineEnergy_1Darray),len(sizeArray)))
    observableErrorBarN_2Darray = np.zeros((len(examineEnergy_1Darray),len(sizeArray)))
    binEnergy_2Darray = np.zeros((len(examineEnergy_1Darray),len(sizeArray)))
#    numBins = 1000
    

    disNum_found = np.zeros(len(sizeArray))
    for iter in range(0,len(sizeArray)):
        sizeValue = sizeArray[iter]
        hopTypeParam = 0 if hopTypeString == "isotropic" else 1
        
        
        newData2DArray_indices = np.logical_and(np.logical_and(data2Darray[:,4].astype(np.int_)==hopTypeParam,data2Darray[:,0].astype(np.int_)==sizeValue),data2Darray[:,5].astype(np.int_)>=-1)
        newData2DArray = data2Darray[newData2DArray_indices,:]
    
        print newData2DArray
        print newData2DArray.shape
        print np.unique(newData2DArray[:,5]).size
        disNum_found[iter] = newData2DArray.shape[0]/sizeValue**3
        
        
        
        disorderCutoff = int(disNum_found[iter]/2) if halveDisorders == "Y" else -1
        print "{0} total disorders for size {1}".format(disNum_found[iter],sizeValue)
        
        newData2DArray_indices = np.logical_and(np.logical_and(data2Darray[:,4].astype(np.int_)==hopTypeParam,data2Darray[:,0].astype(np.int_)==sizeValue),data2Darray[:,5].astype(np.int_)>=disorderCutoff)
        newData2DArray = data2Darray[newData2DArray_indices,:]
        
        disNum_found[iter] = newData2DArray.shape[0]/sizeValue**3
        print newData2DArray
        print newData2DArray.shape
        print np.unique(newData2DArray[:,5]).size
        print "{0} selected disorders for size {1}".format(disNum_found[iter],sizeValue)
        if np.unique(newData2DArray[:,5]).size != int(disNum_found[iter]):
            sys.exit("Error disorders not selected properly")
#        raw_input("Hit Enter")

        newBandwidthData2DArray_indices = np.logical_and(np.logical_and(bandwidthData2Darray[:,4].astype(np.int_)==hopTypeParam,bandwidthData2Darray[:,0].astype(np.int_)==sizeValue),bandwidthData2Darray[:,5].astype(np.int_)!=-1)
        newBandwidthData2DArray = bandwidthData2Darray[newBandwidthData2DArray_indices,:]
        
        print newBandwidthData2DArray
        print newBandwidthData2DArray.shape
        bandwidth = np.amax(newBandwidthData2DArray[:,6]) - np.amin(newBandwidthData2DArray[:,6])
        
#        if bandwidthOverride == "Y":
#            bandwidth = 2.
        print bandwidth
        
        
        
        #/(sizeValue**3)
        # toPlot_PR_1Darray = 1/newData2DArray[:,-1]



        labelText = r'$N = {0:d}$'.format(sizeValue)

        if plotType == "raw":
            toPlot_PR_1Darray = newData2DArray[:,-1]/((sizeValue)**3) if PR_Div_NCubed == "Y" else newData2DArray[:,-1]
            toPlot_Energy_1Darray = newData2DArray[:,-2]
            
            line, = ax.plot(toPlot_Energy_1Darray,toPlot_PR_1Darray,label=labelText, marker=".",linestyle="None",markersize=1,color=sizeMarkerColor_array[iter])#,marker="None",markersize=2,color=color_1Darray[iter])
        
        elif (plotType == "average") or (plotType == "median"):
            if bandwidthOverride == "N":
                toPlot_Energy_1Darray = newData2DArray[:,-2]/(bandwidth/2.)
            elif bandwidthOverride == "Y":
                toPlot_Energy_1Darray = newData2DArray[:,-2]
            toPlot_PR_1Darray = newData2DArray[:,-1]
            print "Data min: ", np.amin(toPlot_Energy_1Darray)
            print "Data max: ",  np.amax(toPlot_Energy_1Darray)
            if binType == "loglin":
                #            lowerBound = np.amin(data2Darray[:,6])
                #            upperBound = np.amax(data2Darray[:,6])+1E-10
                #            lowerBound = np.amin(data2Darray[:,6])
                #            upperBound = np.amax(data2Darray[:,6])+1E-10
                
#                raw_input()
                lowerBound = np.amin(toPlot_Energy_1Darray)-1E-10
                upperBound = np.amax(toPlot_Energy_1Darray)+1E-10
                log10LowerBound = np.log10(np.abs(lowerBound))
                log10UpperBound = np.log10(np.abs(upperBound))
                
                log10linearPortionHalfWidth = np.log10(linearPortionHalfWidth)
                
                numNegBins = (log10LowerBound-log10linearPortionHalfWidth)*binDensity
                numPosBins = (log10UpperBound-log10linearPortionHalfWidth)*binDensity
                numLinBins = int(np.floor(2.*linearPortionHalfWidth/linBinWidth))
#                print numLinBins

                
                negBins = -1*np.logspace(log10linearPortionHalfWidth,log10LowerBound,num=numNegBins+1)[::-1]
                linearBins = np.linspace(-1*linearPortionHalfWidth,linearPortionHalfWidth,num=numLinBins+1)
                posBins = np.logspace(log10linearPortionHalfWidth,log10UpperBound,num=numPosBins+1)
                print negBins
                print linearBins
                print posBins
                
                
                
                binBoundaries = np.append(np.append(negBins[:-1],linearBins[:-1]),posBins)
                
                print binBoundaries
                
                numBins = binBoundaries.size-1
                print numNegBins
                print numPosBins
                print numLinBins
                print numBins
                    #                raw_input() # Bins line up and are generated correctly
            if binType == "log":
#            lowerBound = np.amin(data2Darray[:,6])
#            upperBound = np.amax(data2Darray[:,6])+1E-10
#            lowerBound = np.amin(data2Darray[:,6])
#            upperBound = np.amax(data2Darray[:,6])+1E-10
                lowerBound = np.amin(toPlot_Energy_1Darray)-1E-10
                upperBound = np.amax(toPlot_Energy_1Darray)+1E-10
                log10LowerBound = np.log10(np.abs(lowerBound))
                log10UpperBound = np.log10(np.abs(upperBound))
                centerBinWidth = 1E-6
                log10CentreBinWidth = np.log10(centerBinWidth)

                numNegBins = (log10LowerBound-log10CentreBinWidth)*binDensity
                numPosBins = (log10UpperBound-log10CentreBinWidth)*binDensity

                negBins = -1*np.logspace(log10CentreBinWidth,log10LowerBound,num=numNegBins+1)[::-1]
                posBins = np.logspace(log10CentreBinWidth,log10UpperBound,num=numPosBins+1)
                print negBins
                print posBins

                binBoundaries = np.append(negBins,posBins)

                numBins = binBoundaries.size-1
                print binBoundaries
                print numNegBins
                print numPosBins
                print numBins
            #                raw_input() # Bins line up and are generated correctly

            if binType == "linear":
                lowerBound = np.amin(toPlot_Energy_1Darray)-1E-10
                
                if manualUpperBoundFlag == "N":
                    upperBound = np.amax(toPlot_Energy_1Darray)+1E-10
                else:
                    upperBound = np.amax(toPlot_Energy_1Darray[toPlot_Energy_1Darray<=manualUpperBound])+1E-10
#                print np.amax(toPlot_Energy_1Darray)+1E-10
#                print upperBound

                print manualUpperBound
                print toPlot_PR_1Darray
                print toPlot_Energy_1Darray
        
                toPlot_PR_1Darray = toPlot_PR_1Darray[toPlot_Energy_1Darray<=manualUpperBound]
                toPlot_Energy_1Darray = toPlot_Energy_1Darray[toPlot_Energy_1Darray<=manualUpperBound]
                
                print toPlot_PR_1Darray
                print toPlot_Energy_1Darray
                
                
                print "New Data min: " , np.amin(toPlot_Energy_1Darray)+1E-10
                print "New Data max: " , np.amax(toPlot_Energy_1Darray)+1E-10
                #                raw_input() # Data selected correctly , for isotropic, r0, at least.
                numBins = int(np.floor((upperBound - lowerBound)/linBinWidth))
                print numBins
                binBoundaries = np.linspace(lowerBound,upperBound,num=numBins+1)

            
#            numBins = 10
#            toPlot_PR_1Darray = np.random.uniform(size=numBins)
#            toPlot_Energy_1Darray = np.random.uniform(low=binBoundaries[0],high=binBoundaries[-1]-1E-10,size=numBins)

#            binBoundaries = np.linspace(lowerBound,upperBound,num=numBins+1)
#            binBoundaries = np.logspace(np.log10(lowerBound),np.log10(upperBound),num=numBins+1)
            print binBoundaries
            averagePR_1Darray = np.zeros(numBins)
            erorbarPR_1Darray = np.zeros(numBins)
            binCentre_1Darray = np.zeros(numBins)
            binCount_1Darray = np.zeros(numBins)
            
            
            cumCount = 0
            
            
            for binNum in range(0,numBins):
                binBot = binBoundaries[binNum]
                binTop = binBoundaries[binNum+1]



                relevantPR_1Darray = toPlot_PR_1Darray[np.logical_and(toPlot_Energy_1Darray >= binBot, toPlot_Energy_1Darray < binTop)] #Double check this -> seems good - JTC
                numPoints = relevantPR_1Darray.size
                print numPoints
                cumCount += numPoints
                binCount_1Darray[binNum] = numPoints
#                print toPlot_PR_1Darray
#                print toPlot_Energy_1Darray
#                print relevantPR_1Darray
#                print binBot
#                print binTop
#                raw_input("---------")

                tFactor = scipy.stats.t.ppf((1+0.95)/2,numPoints-1)
                
                if plotType == "average":
                    averagePR_1Darray[binNum] = np.mean(relevantPR_1Darray)
                elif plotType == "median":
                    averagePR_1Darray[binNum] = np.median(relevantPR_1Darray)
                erorbarPR_1Darray[binNum] = tFactor*np.std(relevantPR_1Darray,ddof=1)/np.sqrt(numPoints)
                binCentre_1Darray[binNum] = (binBot+binTop)/2.

            line = ax.errorbar(binCentre_1Darray,averagePR_1Darray,yerr=erorbarPR_1Darray,label=labelText, marker=markerStyle_array[iter],linestyle="None",markersize=markerSize_array[iter],color=markerColor_array[iter])
            
            for binIter in range(len(examineEnergy_1Darray)):
#                examineBinNum = examineBin_1Darray[binIter]
                examineBinNum = (np.abs(binCentre_1Darray-examineEnergy_1Darray[binIter])).argmin()
                print "#######Bin Chosen#######"
                print examineEnergy_1Darray[binIter]
                print examineBinNum
                print binCentre_1Darray[examineBinNum]
                observableN_2Darray[binIter,iter] = averagePR_1Darray[examineBinNum]
                observableErrorBarN_2Darray[binIter,iter] = erorbarPR_1Darray[examineBinNum]
                binEnergy_2Darray[binIter,iter] = binCentre_1Darray[examineBinNum]
                if hopTypeString == "anisotropic":
                    ax.plot(binCentre_1Darray[examineBinNum], averagePR_1Darray[examineBinNum],marker="o",markersize=10,color="k")
            print "Total num binned points: {0} Original Num Points: {1}".format(cumCount,toPlot_PR_1Darray.size)
            if cumCount != toPlot_PR_1Darray.size:
                sys.exit("ERROR: Number of binned points not equal to number of datapoints!")
            #Plot Bin Histogram
            curFigNum = plt.gcf().number
#            print plt.gcf().number
            figNum += 1
            newFig = plt.figure(figNum,facecolor="white")
            axNew = plt.subplot()
            axNew.plot(binCentre_1Darray,binCount_1Darray, linestyle="None",marker=".")
#            axNew.bar(binCentre_1Darray,binCount_1Darray)
            axNew.set_yscale("log",nonposy="clip")
            axNew.set_xscale("symlog", nonposx='clip',linthreshx=linearPortionHalfWidth)
            newFig.canvas.set_window_title("Histogram N = {0}".format(sizeValue))
#            print plt.gcf().number
            plt.figure(curFigNum)
#            print plt.gcf().number


            
###########################################
#        elif plotType == "eigstateAvg":
##            toPlot_Energy_1Darray = newData2DArray[:,-2]
##            toPlot_PR_1Darray
#            relSizeDisNums, numEigstatesArray = np.unique(newData2DArray[:,-3],return_counts=True)
#            numEigstates = numEigstatesArray[0]
#            if not(np.all(numEigstatesArray==numEigstates)):
#                sys.exit("Varying number of eigenstates")
##            print relSizeDisNums
##            print numEigstatesArray
#            print numEigstates
#
#            reshapedDisArray =  np.reshape(newData2DArray[:,-3].copy(),(numEigstates,-1),order="F")
#            reshapedEnergyArray =  np.reshape(toPlot_Energy_1Darray,(numEigstates,-1),order="F")
#            reshapedPRArray = np.reshape(toPlot_PR_1Darray,(numEigstates,-1),order="F")
##            print reshapedEnergyArray[:,:4]
##            print reshapedPRArray[:,:4]
#            if np.all(np.diff(reshapedEnergyArray,axis=0)>=0):
#                print "Eigenstates sorted properly."
#            else:
#                sys.exit("ERROR: Eigenstates NOT sorted.")
#            avgedEigstatePR_1Darray = np.mean(reshapedPRArray,axis=1)
#            stdDevEigstatePR_1Darray = np.std(reshapedPRArray,axis=1,ddof=1)
#            avgedEigstateEnergy_1Darray = np.mean(reshapedEnergyArray,axis=1)
#            stdDevEigstateEnergy_1Darray = np.std(reshapedEnergyArray,axis=1,ddof=1)
#            print avgedEigstatePR_1Darray.shape
#            print stdDevEigstatePR_1Darray.shape
#            print avgedEigstateEnergy_1Darray.shape
#            print stdDevEigstateEnergy_1Darray.shape
#            print stdDevEigstateEnergy_1Darray/avgedEigstateEnergy_1Darray
#            print stdDevEigstatePR_1Darray/avgedEigstatePR_1Darray
#
#            numDisorders = relSizeDisNums.size
#            tFactor = scipy.stats.t.ppf((1+0.95)/2,numDisorders-1)
#
#            errorBarEigstatePR_1Darray = tFactor*stdDevEigstatePR_1Darray/np.sqrt(numDisorders)
#            errorBarEigstateEnergy_1Darray = tFactor*stdDevEigstateEnergy_1Darray/np.sqrt(numDisorders)
#
#            line = ax.plot(avgedEigstateEnergy_1Darray,avgedEigstatePR_1Darray,label=labelText, marker=".",linestyle="None",markersize=1)
#
#            print np.max(np.abs(errorBarEigstatePR_1Darray/avgedEigstatePR_1Darray))
#            print np.max(np.abs(errorBarEigstateEnergy_1Darray/avgedEigstateEnergy_1Darray))
##################################################
#            line = ax.errorbar(avgedEigstateEnergy_1Darray,avgedEigstatePR_1Darray,yerr=errorBarEigstatePR_1Darray,label=labelText, marker=".",linestyle=":",markersize=1)

#            print avgedEigstateEnergy_1Darray

                #Reshape arrays to make for easy averaging

#            line, = ax.plot(toPlot_Energy_1Darray,toPlot_PR_1Darray,label=labelText, marker=".",linestyle="None",markersize=1)


    
#    minDisNum = int(np.amin(data2Darray[:,5]))
#    maxDisNum = int(np.amax(data2Darray[:,5]))
#
#    for disNum in range(minDisNum,maxDisNum+1):
#
#        newData2DArray = data2Darray[(data2Darray[:,5].astype(np.int_)==disNum),:]
#
#
#
#        print newData2DArray.shape
#
#        toPlot_Energy_1Darray = newData2DArray[:,-2]
#        toPlot_PR_1Darray = newData2DArray[:,-1]
#
#
#
#        labelText = "Test" #r'$N = {0:d}$'.format(sizeValue)
#
#        line, = ax.plot(toPlot_Energy_1Darray,toPlot_PR_1Darray,label=labelText, marker=".",linestyle="None",markersize=1)#,marker="None",markersize=2,color=color_1Darray[iter])

    l_w = 1.5
    fs = 20
    fs2 = 20



    #fig.canvas.set_window_title("EigenvalueGapPlot")

    examineBinColour_1Darray = ["black","black","black","black"]
    if drawLines == "Y":
        binEnergy = np.mean(binEnergy_2Darray,axis=1)
        
        for binIter in range(len(examineEnergy_1Darray)):
#            examineBinNum = examineBin_1Darray[binIter]
            ax.axvline(binEnergy[binIter], color="k")#examineBinColour_1Darray[binIter])


    plt.yticks(fontsize=fs)
    
#    plt.xlabel(r'$\frac{E}{\left(\frac{E_{BW}}{2}\right)}$', fontsize=fs,labelpad=10)
    fs_inc = 10
    if PR_Div_NCubed == "Y":
        plt.xlabel(r'$E (\tilde t)$', fontsize=fs+fs_inc,labelpad=10)

    if hopTypeString == "isotropic":
        if PR_Div_NCubed == "Y":
            plt.ylabel(r'$\frac{\mathrm{PR}}{N^3}$', fontsize=fs+fs_inc+3)
        else:
            plt.ylabel(r'PR', fontsize=fs+fs_inc)
            plt.title(r'Isotropic', fontsize=fs+fs_inc+10,y=1.05)

    if hopTypeString == "anisotropic":
        if PR_Div_NCubed == "N":
            plt.title(r'Anisotropic', fontsize=fs+fs_inc+10,y=1.05)
#            if xTicksArrayFlag == "N":
#                plt.xticks(fontsize=fs)
#            else:
#                plt.xticks(xTicksArray,fontsize=fs)
#            ax2 = ax.twiny()
#            ax2.set_xlabel(r'Isotropic', fontsize=fs+fs_inc)
#            labels = [item.get_text() for item in ax.get_xticklabels()]
#            empty_string_labels = ['']*len(labels)
#            ax2.set_xticklabels(empty_string_labels)
#            plt.tick_params(axis="x",which="both", top="off")

#    plt.ylabel(r'$\frac{\mathrm{PR}}{N^3}$', fontsize=fs)

    #plt.axvline(x=3.,color='red',ls='--',lw=l_w)

    ax.tick_params(axis="both",width=l_w,which="both")
    ax.tick_params(axis="y",width=l_w-0.5,which="minor")
    ax.spines['top'].set_linewidth(l_w)
    ax.spines['bottom'].set_linewidth(l_w)
    ax.spines['left'].set_linewidth(l_w)
    ax.spines['right'].set_linewidth(l_w)
    

    if hopTypeString == "isotropic" and plotType == "average":
        ax.set_yscale("linear")
        ax.set_xscale("linear")
        plt.xticks(fontsize=fs-5)
        ax.set_xlim(xLimL,xLimU)
    elif hopTypeString == "isotropic" and plotType == "raw":
        ax.set_yscale("log", nonposx='clip')
        if linearScale == "N":
            ax.set_xscale("symlog", nonposx='clip',linthreshx=linearPortionHalfWidth)
            xaxis = plt.gca().xaxis
            xaxis.set_minor_locator(MinorSymLogLocator(linearPortionHalfWidth))
        else:
            xaxis = plt.gca().xaxis
            xaxis.set_minor_locator(AutoMinorLocator(5))
        if xTicksArrayFlag == "N":
            plt.xticks(fontsize=fs)
        else:
            plt.xticks(xTicksArray,xTicksLabels,fontsize=fs)
    #        ax.set_xlim(xLimL,xLimU)
#        ax.set_yscale("log", nonposx='clip')
#        ax.set_xscale("symlog", nonposx='clip',linthreshx=linearPortionHalfWidth)
#        plt.xticks(xTicksArray,fontsize=fs-5)
#        ax.set_xlim(xLimL,xLimU)
    elif hopTypeString == "anisotropic" and plotType == "average":
        ax.set_yscale("log", nonposx='clip')
        ax.set_xscale("symlog", nonposx='clip',linthreshx=linearPortionHalfWidth)
        plt.xticks(fontsize=fs-8)
    elif hopTypeString == "anisotropic" and plotType == "raw":
        ax.set_yscale("log", nonposx='clip')
        if linearScale == "N":
            ax.set_xscale("symlog", nonposx='clip',linthreshx=linearPortionHalfWidth)
            xaxis = plt.gca().xaxis
            xaxis.set_minor_locator(MinorSymLogLocator(linearPortionHalfWidth))
        else:
            xaxis = plt.gca().xaxis
            xaxis.set_minor_locator(AutoMinorLocator(5))

        if xTicksArrayFlag == "N":
            plt.xticks(fontsize=fs)
        else:
            plt.xticks(xTicksArray,xTicksLabels,fontsize=fs)
#        ax.set_xlim(xLimL,xLimU)
    else:
        sys.exit("Hopping Type and Plot Type pairing not set up.")

    ax.tick_params(axis="x",length=9,which="major")
    ax.tick_params(axis="x",length=4,which="minor")
    ax.tick_params(axis="y",length=7,which="major")
    ax.tick_params(axis="y",length=4,which="minor")
    

#        ax.set_xticks([-1E1,0,1E1,1E2,1E3,1E4])
#        ax.set_xticks([],minor=True)

    if plotType == "raw":
        pass
#        ax.legend(markerscale=10)
    else:
        ax.legend()
    dpi_man = 150

    print ax.figure.get_size_inches()
    
    plt.tight_layout()
    print ax.figure.get_size_inches()
    set_size(5,4,ax,dpi_man)
    print ax.figure.get_size_inches()

    plotTypeString = "{0}_halfDis".format(plotType) if halveDisorders == "Y" else plotType
    plotTypeString = plotTypeString + "_divNCubed" if PR_Div_NCubed == "Y" else plotTypeString
    figureFilename = "p1_{0}_{1}_{2}.png".format(firstInput[:-14],hopTypeString,plotTypeString)
    fig.savefig(figureFilename, format='png', dpi=dpi_man)

    #Fractal Dimension Graph
    if plotType != "raw" and hopTypeString == "anisotropic":
        figNum += 1
        fig = plt.figure(figNum,facecolor="white")
        ax = plt.subplot()
        
        plt.yticks(fontsize=fs)
        
        # plt.xlabel(r'$\ln{N}$', fontsize=fs,labelpad=10)
        # plt.ylabel(r'$\ln{\mathrm{PR}}$', fontsize=fs)
        plt.xlabel(r'$N$', fontsize=fs,labelpad=10)
        plt.ylabel(r'PR', fontsize=fs)
    #

        #plt.axvline(x=3.,color='red',ls='--',lw=l_w)

        ax.tick_params(axis="both",width=l_w,which="both")
        ax.tick_params(axis="y",width=l_w-0.5,which="minor")
        ax.spines['top'].set_linewidth(l_w)
        ax.spines['bottom'].set_linewidth(l_w)
        ax.spines['left'].set_linewidth(l_w)
        ax.spines['right'].set_linewidth(l_w)
        
        ax.set_yscale("log", nonposx='clip')
        ax.set_xscale("log", nonposx='clip')
        ax.tick_params(axis="x",length=7,which="major")
        ax.tick_params(axis="x",length=4,which="minor")
        ax.tick_params(axis="y",length=7,which="major")
        ax.tick_params(axis="y",length=4,which="minor")
        
        binEnergy = np.mean(binEnergy_2Darray,axis=1)
        binEnergyStdDev = np.std(binEnergy_2Darray,axis=1,ddof=1)
        print binEnergy
        print binEnergyStdDev/binEnergy
        
        
#        if np.any(np.abs(binEnergy_2Darray.T-binEnergy)>1E-14):
#            sys.exit("Bin energies don't match.")

        print observableN_2Darray
        
        for binIter in range(len(examineEnergy_1Darray)):
            slope, intercept, r_value, p_value, std_err = scipy.stats.linregress(np.log(sizeArray),np.log(observableN_2Darray[binIter,:]))
            print slope, intercept, r_value, p_value, std_err
            
            lineOfBestFit = np.exp(slope*np.log(sizeArray) + intercept)
            
            labelText = "E = {0:.1E}, m = {1:.5E}".format(binEnergy[binIter],slope)
         
            # line = ax.errorbar(np.log(sizeArray),np.log(observableN_2Darray[binIter,:]),yerr=np.log(observableErrorBarN_2Darray[binIter,:]),label=labelText,marker=".",markersize=7,linestyle="None")
            # line, = ax.plot(np.log(sizeArray),np.log(observableN_2Darray[binIter,:]),label=labelText,marker=".",markersize=7,linestyle="None")
            
            line2, = ax.plot(sizeArray,lineOfBestFit,marker="None",linestyle="--",color="k")
            line, = ax.plot(sizeArray,observableN_2Darray[binIter,:],label=labelText,marker=".",markersize=7,linestyle="None")
        
        
        ax.legend()
        
        plt.tight_layout()
        figureFilename = "p1_{0}_{1}_fractalDim.png".format(firstInput[:-14],hopTypeString)
        fig.savefig(figureFilename, format='png', dpi=150)

    
    for iter in range(0,len(sizeArray)):
        print "{0} disorders for size {1}".format(disNum_found[iter],sizeArray[iter])
plt.show()






















