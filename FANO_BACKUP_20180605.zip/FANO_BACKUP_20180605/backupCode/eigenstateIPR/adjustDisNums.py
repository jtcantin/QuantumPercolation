import sys
import numpy as numpy
from os import listdir, rename
from os.path import isfile, join, isdir
import os.path
import string

dirToMod = sys.argv[2]
numToAdd = int(sys.argv[1])

datafileList = [f for f in listdir(dirToMod) if (isfile(join(dirToMod,f)))]

for fileName in datafileList:
    if "Eval" in fileName or "IPR" in fileName:
        fileNamePieces = fileName.split("_")
        newDisNum = int(fileNamePieces[-2])+numToAdd
#        print fileNamePieces

        fileNamePieces[-2] = str(newDisNum)
        
        newFilename = string.join(fileNamePieces,"_")+"TEMP"
        print "Old: ", fileName
        print "New: ", newFilename
    
        rename(join(dirToMod,fileName), join(dirToMod,newFilename))

#        print fileNamePieces
#        raw_input()


    else:
        continue

datafileList = [f for f in listdir(dirToMod) if (isfile(join(dirToMod,f)))]

for fileName in datafileList:
    if "TEMP" == fileName[-4:]:
        rename(join(dirToMod,fileName), join(dirToMod,fileName[:-4]))

#Put a file as a reminder of what means what:
reminderFile = open(join(dirToMod,"FilenameNOTES.txt"),'w')
reminderFile.write("The following was added to the disorder number of all IPR and Eval files: {0}\n The disorder and occupation filenames were not touched and reflect the original disorder numbering.\n No other filenames were modified.".format(numToAdd))
reminderFile.close()

