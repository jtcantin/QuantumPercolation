import numpy as np
import matplotlib
#matplotlib.use('agg')
import matplotlib.pyplot as plt
import sys
from os import listdir
from os.path import isfile, join, isdir
import scipy.stats

np.set_printoptions(threshold=10000,linewidth=2000,precision=4,suppress=False)

def floatEqual(a,b):
    if np.abs((a-b)/np.minimum(a,b)) < 1E-13:
        return True
    else:
        return False

firstInput = sys.argv[1]

if isdir(firstInput):
    dataDir = firstInput


    dataSubDirList = [dir for dir in listdir(dataDir) if (isdir(join(dataDir,dir)))]
    numDir = len(dataSubDirList)

    data2DList = []

    for dirNum in range(0,numDir):
        currentDataDir = dataSubDirList[dirNum]
        parameterList = currentDataDir.split("_")
        print "Directory {0} of {1} ".format(dirNum+1,numDir)
        print currentDataDir

        size = int(parameterList[1].strip("N"))
        pVal = 1. - float(parameterList[2].strip("q"))/100.
        wVal = float(parameterList[3].strip("w"))
        rangeExp = 100000. if parameterList[4].strip("r-") == "TB" else float(parameterList[4].strip("r-"))
        hopType = (1 if parameterList[5] == "anisotropic" else 0)#0 means isotropic, 1 means anisotropic
    #    print size
    #    print pVal
    #    print wVal
    #    print rangeExp
    #    print hopType

        datafileList = [f for f in listdir(join(dataDir,currentDataDir)) if (isfile(join(dataDir,currentDataDir,f))) and ("IPR.txt" in f)]
        numDatafiles = len(datafileList)
    #    print numDatafiles

        for datafileNum in range(0,numDatafiles):
            datafile = join(dataDir,currentDataDir,datafileList[datafileNum])
            disNum = int(datafileList[datafileNum].split("_")[3])
            energyIPR_2Darray = np.loadtxt(datafile)
            
            print "{0} of {1}".format(datafileNum+1,numDatafiles)
            for iter in range(0,energyIPR_2Darray.shape[0]):
                appendList = [size, pVal, wVal, rangeExp, hopType, disNum, energyIPR_2Darray[iter,0], energyIPR_2Darray[iter,1]]
                data2DList.append(appendList)
    #    print datafileList

    #Convert IPR to PR
    data2Darray = np.array(data2DList)
    data2Darray[:,-1] = 1./data2Darray[:,-1]
    
    print "Saving collected data."
    totalDatafilename = str(dataDir.split("/")[-2])+"_collected.npy"#.txt"
#    np.savetxt(totalDatafilename, data2Darray, header=" 0     1      2       3        4        5       6    7 \nsize, pVal, wVal, rangeExp, hopType, disNum, energy, PR")
    np.save(totalDatafilename,data2Darray)
    print "Data saved to: ", totalDatafilename

elif isfile(firstInput):
    print "Loading data from: ", firstInput
#    data2Darray = np.loadtxt(firstInput)
    data2Darray = np.load(firstInput)
    print "Data loaded."
    print "data2Darray.shape: ", data2Darray.shape
    #data2Darray columns:
    # 0     1      2       3        4        5       6    7
    #size, pVal, wVal, rangeExp, hopType, disNum, energy, PR

    #print data2Darray[12654:12674,:]
    
    #Get bandwidths for systems
    secondInput = sys.argv[2]
    print "Loading data from: ", secondInput
    #    data2Darray = np.loadtxt(secondInput)
    bandwidthData2Darray = np.load(secondInput)
    print "Data loaded."
    print "bandwidthData2Darray.shape: ", bandwidthData2Darray.shape
    
    
    figNum = 0
    figNum += 1
    fig = plt.figure(figNum,facecolor="white")
    ax = plt.subplot()
    
    sizeArray = [31,21,11]
    hopTypeString = "isotropic" #"anisotropic", "isotropic"
    plotType = "average" #"raw","average","median","eigstateAvg"
    binDensity = 9 #per order of magnitude
    linBinWidth = 0.01
    upperBound = 2.
    lowerBound = -2.
    centerBinWidth = 1E-6#1E-6
    examineEnergy_1Darray = [-1E9,-1E-1,1E-1,1E9]#[-1E9,-2,-1,1E9]#[-1E9,-1E-1,1E-1,1E9]#large values for the highest energy
#    examineBin_1Darray = [85,-1]#75,60
    observableN_2Darray = np.zeros((len(examineEnergy_1Darray),len(sizeArray)))
    observableErrorBarN_2Darray = np.zeros((len(examineEnergy_1Darray),len(sizeArray)))
    binEnergy_2Darray = np.zeros((len(examineEnergy_1Darray),len(sizeArray)))
#    numBins = 1000
    

    
    for iter in range(0,len(sizeArray)):
        sizeValue = sizeArray[iter]
        hopTypeParam = 0 if hopTypeString == "isotropic" else 1
    
        newData2DArray_indices = np.logical_and(np.logical_and(np.logical_and(data2Darray[:,4].astype(np.int_)==hopTypeParam,data2Darray[:,0].astype(np.int_)==sizeValue),data2Darray[:,5].astype(np.int_)!=-1),data2Darray[:,6].astype(np.int_)<=40)
        newData2DArray = data2Darray[newData2DArray_indices,:]
    
        print newData2DArray
        print newData2DArray.shape
        print "{0} disorders for size {1}".format(newData2DArray.shape[0]/sizeValue**3,sizeValue)
        
        
        newBandwidthData2DArray_indices = np.logical_and(np.logical_and(bandwidthData2Darray[:,4].astype(np.int_)==hopTypeParam,bandwidthData2Darray[:,0].astype(np.int_)==sizeValue),bandwidthData2Darray[:,5].astype(np.int_)!=-1)
        newBandwidthData2DArray = bandwidthData2Darray[newBandwidthData2DArray_indices,:]
        
        print newBandwidthData2DArray
        print newBandwidthData2DArray.shape
        bandwidth = np.amax(newBandwidthData2DArray[:,6]) - np.amin(newBandwidthData2DArray[:,6])
        
        disorderStrength = float(sys.argv[3])
        
        bandwidth = disorderStrength
        print bandwidth
        
        
        
        toPlot_Energy_1Darray = newData2DArray[:,-2]/(bandwidth/2.)
        toPlot_PR_1Darray = newData2DArray[:,-1]#/(sizeValue**3)
        # toPlot_PR_1Darray = 1/newData2DArray[:,-1]



        labelText = r'$N = {0:d}$'.format(sizeValue)

        if plotType == "raw":
            line, = ax.plot(toPlot_Energy_1Darray,toPlot_PR_1Darray,label=labelText, marker=".",linestyle="None",markersize=1)#,marker="None",markersize=2,color=color_1Darray[iter])
        
        elif (plotType == "average") or (plotType == "median"):
            #  #          lowerBound = np.amin(data2Darray[:,6])
# #           upperBound = np.amax(data2Darray[:,6])+1E-10
##            lowerBound = np.amin(data2Darray[:,6])
##            upperBound = np.amax(data2Darray[:,6])+1E-10
            lowerBound = np.amin(toPlot_Energy_1Darray)
            upperBound = np.amax(toPlot_Energy_1Darray)+1E-10
#            log10LowerBound = np.log10(np.abs(lowerBound))
#            log10UpperBound = np.log10(np.abs(upperBound))
#
#            log10CentreBinWidth = np.log10(centerBinWidth)
#
#            numNegBins = (log10LowerBound-log10CentreBinWidth)*binDensity
#            numPosBins = (log10UpperBound-log10CentreBinWidth)*binDensity
#
#            negBins = -1*np.logspace(log10CentreBinWidth,log10LowerBound,num=numNegBins+1)[::-1]
#            posBins = np.logspace(log10CentreBinWidth,log10UpperBound,num=numPosBins+1)
#            print negBins
#            print posBins
#
#            binBoundaries = np.append(negBins,posBins)

#            numBins = binBoundaries.size-1
#            print numNegBins
#            print numPosBins
#            print numBins
            numBins = int(np.floor((upperBound - lowerBound)/linBinWidth))
            print numBins
            binBoundaries = np.linspace(lowerBound,upperBound,num=numBins+1)
#            binBoundaries = np.logspace(np.log10(lowerBound),np.log10(upperBound),num=numBins+1)

            print binBoundaries
            print binBoundaries.size
#            raw_input()
            averagePR_1Darray = np.zeros(numBins)
            erorbarPR_1Darray = np.zeros(numBins)
            binCentre_1Darray = np.zeros(numBins)
            
            cumCount = 0
            
            for binNum in range(0,numBins):
                binBot = binBoundaries[binNum]
                binTop = binBoundaries[binNum+1]

                relevantPR_1Darray = toPlot_PR_1Darray[np.logical_and(toPlot_Energy_1Darray >= binBot, toPlot_Energy_1Darray < binTop)] #Double check this
                print relevantPR_1Darray.size
                numPoints = relevantPR_1Darray.size
                cumCount += numPoints
                
                tFactor = scipy.stats.t.ppf((1+0.95)/2,numPoints-1)
                
                if plotType == "average":
                    averagePR_1Darray[binNum] = np.mean(relevantPR_1Darray)
                elif plotType == "median":
                    averagePR_1Darray[binNum] = np.median(relevantPR_1Darray)
                erorbarPR_1Darray[binNum] = tFactor*np.std(relevantPR_1Darray,ddof=1)/np.sqrt(numPoints)
                binCentre_1Darray[binNum] = (binBot+binTop)/2.

            line = ax.errorbar(binCentre_1Darray,averagePR_1Darray,yerr=erorbarPR_1Darray,label=labelText, marker=".",linestyle="None",markersize=8)
            
            for binIter in range(len(examineEnergy_1Darray)):
#                examineBinNum = examineBin_1Darray[binIter]
                examineBinNum = (np.abs(binCentre_1Darray-examineEnergy_1Darray[binIter])).argmin()
                print "#######Bin Chosen#######"
                print examineEnergy_1Darray[binIter]
                print examineBinNum
                print binCentre_1Darray[examineBinNum]
                observableN_2Darray[binIter,iter] = averagePR_1Darray[examineBinNum]
                observableErrorBarN_2Darray[binIter,iter] = erorbarPR_1Darray[examineBinNum]
                binEnergy_2Darray[binIter,iter] = binCentre_1Darray[examineBinNum]
                ax.plot(binCentre_1Darray[examineBinNum], averagePR_1Darray[examineBinNum],marker="o",markersize=10,color="k")
            print "Total num binned points: {0} Original Num Points: {1}".format(cumCount,toPlot_PR_1Darray.size)
            if cumCount != toPlot_PR_1Darray.size:
                sys.exit("ERROR: Number of binned points not equal to number of datapoints!")
            
            
        elif plotType == "eigstateAvg":
#            toPlot_Energy_1Darray = newData2DArray[:,-2]
#            toPlot_PR_1Darray
            relSizeDisNums, numEigstatesArray = np.unique(newData2DArray[:,-3],return_counts=True)
            numEigstates = numEigstatesArray[0]
            if not(np.all(numEigstatesArray==numEigstates)):
                sys.exit("Varying number of eigenstates")
#            print relSizeDisNums
#            print numEigstatesArray
            print numEigstates

            reshapedDisArray =  np.reshape(newData2DArray[:,-3].copy(),(numEigstates,-1),order="F")
            reshapedEnergyArray =  np.reshape(toPlot_Energy_1Darray,(numEigstates,-1),order="F")
            reshapedPRArray = np.reshape(toPlot_PR_1Darray,(numEigstates,-1),order="F")
#            print reshapedEnergyArray[:,:4]
#            print reshapedPRArray[:,:4]
            if np.all(np.diff(reshapedEnergyArray,axis=0)>=0):
                print "Eigenstates sorted properly."
            else:
                sys.exit("ERROR: Eigenstates NOT sorted.")
            avgedEigstatePR_1Darray = np.mean(reshapedPRArray,axis=1)
            stdDevEigstatePR_1Darray = np.std(reshapedPRArray,axis=1,ddof=1)
            avgedEigstateEnergy_1Darray = np.mean(reshapedEnergyArray,axis=1)
            stdDevEigstateEnergy_1Darray = np.std(reshapedEnergyArray,axis=1,ddof=1)
            print avgedEigstatePR_1Darray.shape
            print stdDevEigstatePR_1Darray.shape
            print avgedEigstateEnergy_1Darray.shape
            print stdDevEigstateEnergy_1Darray.shape
            print stdDevEigstateEnergy_1Darray/avgedEigstateEnergy_1Darray
            print stdDevEigstatePR_1Darray/avgedEigstatePR_1Darray

            numDisorders = relSizeDisNums.size
            tFactor = scipy.stats.t.ppf((1+0.95)/2,numDisorders-1)

            errorBarEigstatePR_1Darray = tFactor*stdDevEigstatePR_1Darray/np.sqrt(numDisorders)
            errorBarEigstateEnergy_1Darray = tFactor*stdDevEigstateEnergy_1Darray/np.sqrt(numDisorders)
            
            line = ax.plot(avgedEigstateEnergy_1Darray,avgedEigstatePR_1Darray,label=labelText, marker=".",linestyle="None",markersize=1)

            print np.max(np.abs(errorBarEigstatePR_1Darray/avgedEigstatePR_1Darray))
            print np.max(np.abs(errorBarEigstateEnergy_1Darray/avgedEigstateEnergy_1Darray))

#            line = ax.errorbar(avgedEigstateEnergy_1Darray,avgedEigstatePR_1Darray,yerr=errorBarEigstatePR_1Darray,label=labelText, marker=".",linestyle=":",markersize=1)

#            print avgedEigstateEnergy_1Darray

                #Reshape arrays to make for easy averaging

#            line, = ax.plot(toPlot_Energy_1Darray,toPlot_PR_1Darray,label=labelText, marker=".",linestyle="None",markersize=1)


    
#    minDisNum = int(np.amin(data2Darray[:,5]))
#    maxDisNum = int(np.amax(data2Darray[:,5]))
#
#    for disNum in range(minDisNum,maxDisNum+1):
#
#        newData2DArray = data2Darray[(data2Darray[:,5].astype(np.int_)==disNum),:]
#
#
#
#        print newData2DArray.shape
#
#        toPlot_Energy_1Darray = newData2DArray[:,-2]
#        toPlot_PR_1Darray = newData2DArray[:,-1]
#
#
#
#        labelText = "Test" #r'$N = {0:d}$'.format(sizeValue)
#
#        line, = ax.plot(toPlot_Energy_1Darray,toPlot_PR_1Darray,label=labelText, marker=".",linestyle="None",markersize=1)#,marker="None",markersize=2,color=color_1Darray[iter])

    l_w = 1.5
    fs = 20
    fs2 = 20



    #fig.canvas.set_window_title("EigenvalueGapPlot")

    examineBinColour_1Darray = ["black","black","black","black"]
    if plotType != "raw":
        binEnergy = np.mean(binEnergy_2Darray,axis=1)
        
        for binIter in range(len(examineEnergy_1Darray)):
#            examineBinNum = examineBin_1Darray[binIter]
            ax.axvline(binEnergy[binIter], color=examineBinColour_1Darray[binIter])


    plt.yticks(fontsize=fs)
    
    plt.xlabel(r'$\frac{E}{\left(\frac{W}{2}\right)}$', fontsize=fs,labelpad=10)
    plt.ylabel(r'PR', fontsize=fs)
#    plt.ylabel(r'$\frac{\mathrm{PR}}{N^3}$', fontsize=fs)

    #plt.axvline(x=3.,color='red',ls='--',lw=l_w)

    ax.tick_params(axis="both",width=l_w,which="both")
    ax.tick_params(axis="y",width=l_w-0.5,which="minor")
    ax.spines['top'].set_linewidth(l_w)
    ax.spines['bottom'].set_linewidth(l_w)
    ax.spines['left'].set_linewidth(l_w)
    ax.spines['right'].set_linewidth(l_w)

#    ax.set_ylim(0,10)
#    ax.set_xlim(-2,2)
#    ax.set_yscale("log", nonposx='clip')
#    ax.set_xscale("symlog", nonposx='clip',linthreshx=1E-4)#1E-5
    ax.tick_params(axis="x",length=7,which="major")
    ax.tick_params(axis="x",length=4,which="minor")
    ax.tick_params(axis="y",length=7,which="major")
    ax.tick_params(axis="y",length=4,which="minor")
    
    if hopTypeString == "isotropic":
        plt.xticks(fontsize=fs-5)
    elif hopTypeString == "anisotropic":
        plt.xticks(fontsize=fs-8)
    else:
        sys.exit('Error')
#        ax.set_xticks([-1E1,0,1E1,1E2,1E3,1E4])
#        ax.set_xticks([],minor=True)

    if plotType == "raw":
        ax.legend(markerscale=10)
    else:
        ax.legend()
    
    plt.tight_layout()

    figureFilename = "p1_{0}_{1}_{2}.png".format(firstInput[:-14],hopTypeString,plotType)
    fig.savefig(figureFilename, format='png', dpi=150)

    #Fractal Dimension Graph
    if plotType != "raw":
        figNum += 1
        fig = plt.figure(figNum,facecolor="white")
        ax = plt.subplot()
        
        plt.yticks(fontsize=fs)
        
        # plt.xlabel(r'$\ln{N}$', fontsize=fs,labelpad=10)
        # plt.ylabel(r'$\ln{\mathrm{PR}}$', fontsize=fs)
        plt.xlabel(r'$N$', fontsize=fs,labelpad=10)
        plt.ylabel(r'PR', fontsize=fs)
    #    plt.ylabel(r'$\frac{\mathrm{PR}}{N^3}$', fontsize=fs)

        #plt.axvline(x=3.,color='red',ls='--',lw=l_w)

        ax.tick_params(axis="both",width=l_w,which="both")
        ax.tick_params(axis="y",width=l_w-0.5,which="minor")
        ax.spines['top'].set_linewidth(l_w)
        ax.spines['bottom'].set_linewidth(l_w)
        ax.spines['left'].set_linewidth(l_w)
        ax.spines['right'].set_linewidth(l_w)
        
        ax.set_yscale("log", nonposx='clip')
        ax.set_xscale("log", nonposx='clip')
        ax.tick_params(axis="x",length=7,which="major")
        ax.tick_params(axis="x",length=4,which="minor")
        ax.tick_params(axis="y",length=7,which="major")
        ax.tick_params(axis="y",length=4,which="minor")
        
        binEnergy = np.mean(binEnergy_2Darray,axis=1)
        binEnergyStdDev = np.std(binEnergy_2Darray,axis=1,ddof=1)
        print binEnergy
        print binEnergyStdDev/binEnergy
        
        
#        if np.any(np.abs(binEnergy_2Darray.T-binEnergy)>1E-14):
#            sys.exit("Bin energies don't match.")

        print observableN_2Darray
        
        for binIter in range(len(examineEnergy_1Darray)):
            slope, intercept, r_value, p_value, std_err = scipy.stats.linregress(np.log(sizeArray),np.log(observableN_2Darray[binIter,:]))
            print slope, intercept, r_value, p_value, std_err
            
            lineOfBestFit = np.exp(slope*np.log(sizeArray) + intercept)
            
            labelText = "E = {0:.1E}, m = {1:.5E}".format(binEnergy[binIter],slope)
         
            # line = ax.errorbar(np.log(sizeArray),np.log(observableN_2Darray[binIter,:]),yerr=np.log(observableErrorBarN_2Darray[binIter,:]),label=labelText,marker=".",markersize=7,linestyle="None")
            # line, = ax.plot(np.log(sizeArray),np.log(observableN_2Darray[binIter,:]),label=labelText,marker=".",markersize=7,linestyle="None")
            
            line2, = ax.plot(sizeArray,lineOfBestFit,marker="None",linestyle="--",color="k")
            line, = ax.plot(sizeArray,observableN_2Darray[binIter,:],label=labelText,marker=".",markersize=7,linestyle="None")
        
        
        ax.legend()
        
        plt.tight_layout()
        figureFilename = "p1_{0}_{1}_fractalDim.png".format(firstInput[:-14],hopTypeString)
        fig.savefig(figureFilename, format='png', dpi=150)

    

plt.show()






















