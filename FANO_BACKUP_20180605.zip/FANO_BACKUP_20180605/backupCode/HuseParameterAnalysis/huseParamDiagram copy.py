import numpy as np
import scipy.interpolate
import sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.ticker as tickerMod

np.set_printoptions(threshold=1000,linewidth=2000,precision=4,suppress=False)

############################################
#Data from Root and Skinner 1988
p_q = np.array([0.477,0.494,0.606,0.636,0.745])
w_q = np.array([0.0,2.0,4.0,6.0,8.0])
error_q = np.array([0.011,0.026,0.051,0.047,0.098])
w_c = np.array([15.95,13.33,10.40,8.39])
p_c = np.array([1.0,0.9,0.8,0.7])
error_c = np.array([0.25,0.66,0.87,0.59])
############################################

dataFile = sys.argv[1]

data_2Darray = np.loadtxt(dataFile).T

#print data_2Darray

sortStack = np.vstack((data_2Darray[2,:],data_2Darray[1,:],data_2Darray[0,:]))

#print data_2Darray[:3,:]
data_2Darray_Nqw_srtd_indices = np.lexsort(sortStack)

data_2Darray_Nqw_srtd = data_2Darray[:,data_2Darray_Nqw_srtd_indices]

#print data_2Darray_Nqw_srtd

#unique_qVals_1Darray = np.unique(np.around(data_2Darray_Nqw_srtd[1,:],decimals=3))
#unique_wVals_1Darray = np.unique(np.around(data_2Darray_Nqw_srtd[2,:],decimals=3))
#
#print unique_qVals_1Darray
#print unique_wVals_1Darray

numDataPoints = len(data_2Darray[0,:])

#for iter in range(numDataPoints):
#    for jiter in range(numDataPoints):
#
#        stdError = stdDevB/np.sqrt(numDataValues)
#    
#        tDistFactor = spStat.t.ppf(1. - (alphaCI/2.), numDataValues-1)
#        errorBarHalf = tDistFactor * stdError

pMin = 0.05
pMax = 1
wMin = 0
wMax = 20

pStartArray = np.linspace(pMin,pMax,num=1000)
wStartArray = np.linspace(wMin,wMax,num=1000)

qPlotArray = data_2Darray_Nqw_srtd[1,:]
wPlotArray = data_2Darray_Nqw_srtd[2,:]
huseParamPlotArray = data_2Darray_Nqw_srtd[3,:]

print qPlotArray
print wPlotArray
print huseParamPlotArray
    
grid_p, grid_w = np.meshgrid(pStartArray,wStartArray)
huseParamPlot2DArray = scipy.interpolate.griddata((1.-qPlotArray, wPlotArray), huseParamPlotArray, (grid_p, grid_w), method='cubic', rescale=True)#method='cubic'

figNum = 1
fig = plt.figure(figNum,facecolor="white")
ax = plt.subplot()

cm = plt.cm.get_cmap('hot')

colourList = ["red","blue","black"]
markerList = ["D","s","."]
markerSizeList = [5,5,15]

colourBarMax = 0.53
colourBarMin = 0.38 #2.*np.log(2)-1
print colourBarMin

im = plt.imshow(huseParamPlot2DArray, vmin=colourBarMin, vmax=colourBarMax, interpolation='nearest',origin='lower',aspect='auto',extent=[pMin,pMax,wMin,wMax], cmap=cm)
cbar = plt.colorbar(im)

cbar.outline.set_linewidth(3.0)
cbar.ax.set_ylabel(r'$r$',size=24,rotation=0,labelpad=19,verticalalignment="center")
cbar.ax.tick_params(direction="inout", length=7, width=2, colors='k', top='off', right='on', labelsize=16)

#Plot Root and Skinner 1988 data
#ax.errorbar(p_c,w_c,yerr=error_c,fmt='o',clip_on=False,color='g',zorder=10)
#ax.errorbar(p_q,w_q,xerr=error_q,fmt='o',clip_on=False,color='g',zorder=10)

#Location of Datapoints
plt.scatter(1.-qPlotArray, wPlotArray, facecolors='w', edgecolors='k', s=50, clip_on=False,zorder=100)

#Cross hatching
x_fill = np.linspace(0.,pMax,100)
y_lower = np.zeros(100)
y_upper = (wMax-wMin)*np.ones(100)
ax.fill_between(x_fill,y_lower,y_upper,facecolor = 'white',zorder=0)
ax.fill_between(x_fill,y_lower,y_upper,facecolor = 'green',zorder=0)#,hatch="xxx"

plt.ylim(wMin,wMax)
plt.xlim(pMin,pMax)

def cust_formatter(x,pos):
    if x < 0.1:
        return "%0.2f" % (x)
    else:
        return "%0.1f" % (x)

ax.xaxis.set_ticks(np.array([0.05,0.2,0.4,0.6,0.8,1.0]))
ax.xaxis.set_major_formatter(tickerMod.FuncFormatter(cust_formatter))

plt.xlabel(r'$p$', fontsize=24, labelpad=-3.)
plt.ylabel(r'$w$', fontsize=24)

[i.set_linewidth(3.0) for i in ax.spines.itervalues()]
for tick in ax.get_xaxis().get_major_ticks():
    tick.set_pad(8.)
    tick.label1 = tick._get_text1()
for tick in ax.get_yaxis().get_major_ticks():
    tick.set_pad(10.)
    tick.label1 = tick._get_text1()
for label in ax.yaxis.get_ticklabels():
    label.set_verticalalignment('center')

ax.tick_params(direction="inout", length=10, width=2, colors='k', top='off', right='off', labelsize=20)

plt.tight_layout()


figureFilename = "huseParamPlot.eps"
#fig.savefig(figureFilename, format='eps', dpi=1200)
fig.savefig(figureFilename, format='eps', dpi=150)
#fig.savefig(figureFilename, format='pdf', dpi=300)

plt.show()









