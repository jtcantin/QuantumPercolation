# To run: name.py [inputDir]


import numpy as np
import sys
from os import listdir
from os.path import isfile, join
import matplotlib.pyplot as plt
import distFit
import scipy.stats as spStat
import scipy.interpolate

np.set_printoptions(threshold=1000,linewidth=2000,precision=4,suppress=False)

#Data from Root and Skinner 1988
p_q = np.array([0.477,0.494,0.606,0.636,0.745])
w_q = np.array([0.0,2.0,4.0,6.0,8.0])
error_q = np.array([0.011,0.026,0.051,0.047,0.098])
w_c = np.array([15.95,13.33,10.40,8.39])
p_c = np.array([1.0,0.9,0.8,0.7])
error_c = np.array([0.25,0.66,0.87,0.59])


alphaCI = 0.05

inputDir = sys.argv[1]
inputFilename = sys.argv[2]
upperBoundFilename = sys.argv[3]
lowerBoundFilename = sys.argv[4]

inputFiles = [ f for f in listdir(inputDir) if (isfile(join(inputDir,f)) and f!="._.DS_Store" and f!=".DS_Store") ]



infoList = []
distArrayList = []
binEdgesArrayList = []
SValsArrayList = []
bDistArrayList = []

#Get info from each datafile
for datafileName in inputFiles:
    print "Reading: {0}".format(datafileName)
    #    datafile = open(datafileName, 'r')
    dataDict = np.load(join(inputDir,datafileName))
    
    infoList.append(dataDict['infoArray'])
    
    #    np.vstack((dist2DArray,dataDict['binnedDataGBNE']))
    distArrayList.append(dataDict['binnedDataGBNE'])
    binEdgesArrayList.append(dataDict['bin_edgesGBNE'])
#    SValsArrayList.append(dataDict['Svals'])
#    bDistArrayList.append(dataDict['brodyDistArray'])


#print infoList
distArrayArray = np.array(distArrayList)
binEdgesArrayArray = np.array(binEdgesArrayList)
#SValsArrayArray = np.array(SValsArrayList)
#bDistArrayArray = np.array(bDistArrayList)



Nlist = []
qList = []
wList = []
bValList = []
for infoArray in infoList:
    Nlist.append(int(infoArray[0]))
    qList.append(float(infoArray[1]))
    wList.append(float(infoArray[2]))
    bValList.append(float(infoArray[8]))


NArray = np.array(Nlist)
qArray = np.array(qList)
wArray = np.array(wList)
bValArray = np.array(bValList)

data2DArray = np.vstack((NArray,qArray,wArray,bValArray))

#print data2DArray

#Sort according to size and then disorder strength
#data2DArray_N_srtd_indices = np.argsort(data2DArray[2])
data2DArray_Nqw_srtd_indices = np.lexsort(np.vstack((wArray,qArray,NArray)))

data2DArray_Nqw_srtd = data2DArray[:,data2DArray_Nqw_srtd_indices]
#print data2DArray_Nqw_srtd

# Sort according to disorder strength

#data2DArray_q_srtd_indices = np.argsort(data2DArray[1])
#
#data2DArray_q_srtd = np.copy(data2DArray[:,data2DArray_q_srtd_indices])

#print data2DArray_q_srtd

#########################
#########################
#Plot
#########################
#########################
figNum = 0

#######
#b vs w
#######


figNum += 1
fig = plt.figure(figNum,facecolor="white")
ax = plt.subplot()

#cm = plt.cm.get_cmap('RdYlBu')
#cm = plt.cm.get_cmap('YlGnBu_r')
#cm = plt.cm.get_cmap('YlOrBr_r')
cm = plt.cm.get_cmap('hot')
#cm = plt.cm.get_cmap('gray')
#cm = plt.cm.get_cmap('')

colourList = ["red","blue","black"]
markerList = ["D","s","."]
markerSizeList = [5,5,15]
typeIndex = 0

newNIndex = 0

plotHeight = 21
plotWidth = 1.

while newNIndex < data2DArray_Nqw_srtd[0].size:

    oldNIndex = newNIndex
    NvalueCurrent = data2DArray_Nqw_srtd[0,oldNIndex]
    newNIndex = np.sum(data2DArray_Nqw_srtd[0] <= data2DArray_Nqw_srtd[0,newNIndex])
#    print newNIndex

    relevant_data2DArray_Nqw_srtd = data2DArray_Nqw_srtd[:, oldNIndex:newNIndex]
    
#    print relevant_data2DArray_Nqw_srtd


    newQIndex = 0
    wPlotList = []
    qPlotList = []
    bPlotList = []
    errorBarList = []
    
    while newQIndex < relevant_data2DArray_Nqw_srtd[1].size:
        oldQIndex = newQIndex
#        qPlotList.append(relevant_data2DArray_Nqw_srtd[1,oldQIndex])

        newQIndex += np.sum(np.abs(relevant_data2DArray_Nqw_srtd[1] - relevant_data2DArray_Nqw_srtd[1,newQIndex]) < 1E-10)
    
        w_relevant_data2DArray_Nqw_srtd = relevant_data2DArray_Nqw_srtd[:, oldQIndex:newQIndex]
    
        newWIndex = 0

        while newWIndex < w_relevant_data2DArray_Nqw_srtd[2].size:

            oldWIndex = newWIndex
            wPlotList.append(w_relevant_data2DArray_Nqw_srtd[2,oldWIndex])
            qPlotList.append(relevant_data2DArray_Nqw_srtd[1,oldQIndex])

            newWIndex += np.sum(np.abs(w_relevant_data2DArray_Nqw_srtd[2] - w_relevant_data2DArray_Nqw_srtd[2,newWIndex]) < 1E-10)

            relevant_bArray = w_relevant_data2DArray_Nqw_srtd[3,oldWIndex:newWIndex]

            meanB = np.mean(relevant_bArray)
            bPlotList.append(meanB)

            numDataValues = relevant_bArray.size
            stdDevB = np.sqrt(np.sum((relevant_bArray - meanB)**2) / (numDataValues - 1))
            stdError = stdDevB/np.sqrt(numDataValues)

            tDistFactor = spStat.t.ppf(1. - (alphaCI/2.), numDataValues-1)
                    
            errorBarHalf = tDistFactor * stdError
                        
            errorBarList.append(errorBarHalf)

#    print wPlotList
#    print qPlotList
#    print bPlotList
#    print errorBarList
    wPlotArray = np.array(wPlotList)
    qPlotArray = np.array(qPlotList)
    bPlotArray = np.array(bPlotList)
    errorBarArray = np.array(errorBarList)

#print data2DArray_Nqw_srtd[0] <= data2DArray_Nqw_srtd[0,0]
#print np.sum(data2DArray_Nqw_srtd[0] <= data2DArray_Nqw_srtd[0,0]) #This gives next index after first value
#print data2DArray_Nqw_srtd[:,data2DArray_Nqw_srtd[0] <= data2DArray_Nqw_srtd[0,0]]






    print qPlotArray
#    print qPlotArray[::-1]
    print wPlotArray
    print bPlotArray
#    bPlot2DArrayOld = np.reshape(np.append(bPlotArray,np.nan),(5,-1)) #r5
#    bPlot2DArrayOld = np.reshape(bPlotArray,(4,-1)) #TB
#    bPlot2DArrayOld = np.reshape(bPlotArray,(5,-1)) #r3
#    vStacked = np.dstack((1.-qPlotArray, wPlotArray))[0,:,:]
#    print vStacked

    pStartArray = np.linspace(0.1,1,num=1000)
    wStartArray = np.linspace(0,20,num=1000)

    grid_p, grid_w = np.meshgrid(pStartArray,wStartArray)

#    grid_q, grid_w = np.mgrid[0:1:1000j,0:20:1000j]
#    print grid_w
#    print grid_q

    bPlotArrayMod = bPlotArray.copy()
    bPlotArrayMod[bPlotArrayMod < -0.1] = 0.953
    print bPlotArrayMod

    bPlot2DArray = scipy.interpolate.griddata((1.-qPlotArray, wPlotArray), bPlotArrayMod, (grid_p, grid_w), method='cubic')
#    print bPlot2DArray
#yerr=errorBarArray
#    sc = plt.scatter(1.-qPlotArray, wPlotArray, c=bPlotArray, vmin=0, vmax=1, s=1296, cmap=cm, clip_on=False)

##############
##############
#    im = plt.imshow(bPlot2DArray, vmin=0., vmax=0.9, interpolation='nearest',origin='lower',aspect='auto',extent=[0,plotWidth,0,plotHeight], cmap=cm)
#    cbar = plt.colorbar(im)
#
#    cbar.outline.set_linewidth(3.0)
#    cbar.ax.set_ylabel(r'$b$',size=24,rotation=0,labelpad=19,verticalalignment="center")
#    cbar.ax.tick_params(direction="inout", length=7, width=2, colors='k', top='off', right='on', labelsize=16)
##############
##############
    
    
#    cbar.ax.set_ylabel_size(20)





#    plt.plot(1.-qPlotArray, wPlotArray, '.', color='0.5', markersize=10, clip_on=False)
###########################################################
###########################################################
#    plt.scatter(1.-qPlotArray, wPlotArray, facecolors='w', edgecolors='k', s=50, clip_on=False,zorder=100)
###########################################################
###########################################################

#    figNum += 1
#    fig = plt.figure(figNum,facecolor="white")
#    ax = plt.subplot()
#    im2 = plt.imshow(np.fliplr(bPlot2DArrayOld), vmin=bPlot2DArray.min(), vmax=bPlot2DArray.max(), interpolation='nearest',origin='lower',extent=[0,1,0,22.5],aspect='auto')
#    plt.colorbar(im)
#    plt.plot(1.-qPlotArray, wPlotArray, 'k.', markersize=50)

#vmin=0.0, vmax=1.0

#    line = ax.errorbar(qPlotArray, bPlotArray, yerr=errorBarArray, marker=markerList[typeIndex], markersize=markerSizeList[typeIndex], label="N={0}".format(NvalueCurrent), clip_on=False, linewidth=1.0, color=colourList[typeIndex])#linewidth=3.0, ls=''
    typeIndex += 1
#    line[-1][0].set_linestyle('--')
#    line, = ax.errorbar(qPlotList, bPlotList, yerr=errorBarList, 'k-',marker=".", markersize=20,linewidth=3.0, label="Diffusive Regime", clip_on=False)
#line, = ax.plot(data2DArray_q_srtd[1], data2DArray_q_srtd[3],'k-',marker=".", markersize=20,linewidth=3.0, label="Diffusive Regime", clip_on=False)
#line2, = ax.plot(second_q_NArray, second_q_bValArray,'k-',marker=".",markersize=20,linewidth=2.0, label="Localized Regime", clip_on=False)
#line, = ax.plot(NArray_srtd, bValArray_srtd,'k-',marker=".",markersize=20,linewidth=2.0)#, label="Local Level Density")
#line2, = ax.plot(eigvals, rhoGauss, color='red', marker="o", label="Gaussian Broadening Method")
#ax.legend()

# Remove plot frame
#ax.set_frame_on(False)

#x_fill = np.linspace(0.,plotWidth,100)
#y_lower = np.zeros(100)
#y_upper = plotHeight*np.ones(100)
#ax.fill_between(x_fill,y_lower,y_upper,facecolor = 'white',zorder=0,hatch="xxx")

#old_settings = np.seterr(all='print')
###########################################################
###########################################################
##Line at b = XXX
#b_line = 0.85 #0.85
#w_cutoff = 0.#0.75 #Use 0 for none
#p5array = grid_p[np.logical_and(np.abs(bPlot2DArray - b_line) < 1e-3,grid_w > w_cutoff)]
#w5array = grid_w[np.logical_and(np.abs(bPlot2DArray - b_line) < 1e-3,grid_w > w_cutoff)]
#ax.plot(p5array, w5array, '-', color="0.5",zorder=2)#color='0.5'

##Line at b = XXX
#b_line = 0.33 #0.34
#w_cutoff = 0.#1.7 #Use 0 for none
#p5array = grid_p[np.logical_and(np.abs(bPlot2DArray - b_line) < 1e-3,grid_w > w_cutoff)]
#w5array = grid_w[np.logical_and(np.abs(bPlot2DArray - b_line) < 1e-3,grid_w > w_cutoff)]
#ax.plot(p5array[0::75], w5array[0::75], 'o', color="white",markeredgecolor="0.6",markersize=4,zorder=10,clip_on=False)#color='0.5'

##Line at b = 0.85
#b_line = 0.85 #0.85
#w_cutoff = 0.#0.75 #Use 0 for none
#p5array = grid_p[np.logical_and(np.abs(bPlot2DArray - b_line) < 1e-3,grid_w > w_cutoff)]
#w5array = grid_w[np.logical_and(np.abs(bPlot2DArray - b_line) < 1e-3,grid_w > w_cutoff)]
#ax.plot(p5array, w5array, '-', color="0.75",zorder=2)#color='0.5'
#
##Line at b = 0.33
#b_line = 0.33 #0.34
#w_cutoff = 0.#1.7 #Use 0 for none
#p5array = grid_p[np.logical_and(np.abs(bPlot2DArray - b_line) < 1e-3,grid_w > w_cutoff)]
#w5array = grid_w[np.logical_and(np.abs(bPlot2DArray - b_line) < 1e-3,grid_w > w_cutoff)]
#ax.plot(p5array, w5array, '-', color="0.75",zorder=2)#color='0.5'

##Line at b = 0.5
#b_line = 0.5 #0.34
#w_cutoff = 0.#1.7 #Use 0 for none
#p5array = grid_p[np.logical_and(np.abs(bPlot2DArray - b_line) < 1e-3,grid_w > w_cutoff)]
#w5array = grid_w[np.logical_and(np.abs(bPlot2DArray - b_line) < 1e-3,grid_w > w_cutoff)]
#ax.plot(p5array, w5array, '-', color='k')#color='0.5'

#tester = np.isfinite(np.abs(bPlot2DArray - b_line))
#
#for j in (np.abs(bPlot2DArray - b_line))[tester==False]:
#    print j
###########################################################
###########################################################

#np.seterr(**old_settings)

#Plot Root and Skinner 1988 data
#ax.errorbar(p_c,w_c,yerr=error_c,fmt='o',clip_on=False,color='g',zorder=10)
#ax.errorbar(p_q,w_q,xerr=error_q,fmt='o',clip_on=False,color='g',zorder=10)

#plt.ylim(0.,np.max(wPlotArray)*1.1)
#plt.xlim(0.,1.01)
plt.ylim(0.,plotHeight)
plt.xlim(0.,plotWidth)
#plt.xlabel(r'Probability of Occupation, $p$', fontsize=16)
#plt.ylabel(r'Disorder Strength, $w$', fontsize=16)
plt.xlabel(r'$p$', fontsize=24, labelpad=-3.)
plt.ylabel(r'$w$', fontsize=24)
#plt.title("Local Level Density", fontsize=18)
#plt.colorbar(sc)
#plt.colorbar(im)
[i.set_linewidth(3.0) for i in ax.spines.itervalues()]
for tick in ax.get_xaxis().get_major_ticks():
    tick.set_pad(8.)
    tick.label1 = tick._get_text1()
for tick in ax.get_yaxis().get_major_ticks():
    tick.set_pad(10.)
    tick.label1 = tick._get_text1()
for label in ax.yaxis.get_ticklabels():
    label.set_verticalalignment('center')

ax.tick_params(direction="inout", length=10, width=2, colors='k', top='off', right='off', labelsize=20)

plt.tight_layout()

###########################################
#Fit N*lambda curve and plot datapoints
###########################################

#N10bqData_w = np.array([12]) #12,13.401293369579101
#N10bqData_p = np.array([0.75])

N10bqData_w = np.array([]) #12,13.401293369579101
N10bqData_p = np.array([])

N20bqData_w = np.array([15.34894588, 12.16045013, 9.796823357])
N20bqData_p = np.array([0.9, 0.75, 0.6])
N20bqData_wUpperErrorBar = np.array([15.705072741199261, 12.89502459491824, 10.350141298848182])
N20bqData_wLowerErrorBar = np.array([14.681928209938881, 11.620501577564937, 8.8629361341483914])

#N20bqData_w = np.array([])
#N20bqData_p = np.array([])

#N30bqData_w = np.array([14.57527357, 12.72326765, 10.30927768])
#N30bqData_p = np.array([0.88, 0.75, 0.63])

#N30bqData_w = np.array([])
#N30bqData_p = np.array([])

N40bqData_w = np.array([12.89316651, 11.13719945, 9.324605444])
N40bqData_wUpperErrorBar = np.array([13.179866382271674, 11.412324109763503, 9.4851052918730439])
N40bqData_wLowerErrorBar = np.array([12.676919918066881, 10.899351758065066, 9.1393761410940364])
N40bqData_p = np.array([0.8, 0.7, 0.6])

#N40bqData_w = np.array([])
#N40bqData_p = np.array([])

N101bqData_w = np.array([  3.1111,   5.4141,   7.5253,   7.7172,   9.8283,  10.0202,  11.9394,  12.1313,  12.3232,  14.2424,  14.4343,  14.6263,  16.3535,  16.5455,  16.7374,  16.9293,  18.6566,  18.8485,  19.0404])
N101bqData_p = np.array([ 0.1636,  0.2818,  0.3909,  0.4,     0.5091,  0.5182,  0.6182,  0.6273,  0.6364,  0.7364,  0.7455,  0.7545,  0.8455,  0.8545,  0.8636,  0.8727,  0.9636,  0.9727,  0.9818])

# N = 10
#ax.plot(N10bqData_p, N10bqData_w, '.g', label="N=10", markersize=4,zorder=10)

# N = 20
yerr20 = np.vstack((N20bqData_w - N20bqData_wLowerErrorBar, N20bqData_wUpperErrorBar - N20bqData_w))
print "yerr20 = ", yerr20
#ax.errorbar(N20bqData_p, N20bqData_w, fmt='^g', yerr=yerr20, label="N=20", markersize=4,zorder=10)


# N = 30
#ax.plot(N30bqData_p, N30bqData_w, '.b', label="N=30",zorder=10)

# N = 40
yerr40 = np.vstack((N40bqData_w - N40bqData_wLowerErrorBar, N40bqData_wUpperErrorBar - N40bqData_w))
print "yerr40 = ", yerr40
#ax.errorbar(N40bqData_p, N40bqData_w, fmt='.r', yerr=yerr40,  label="N=40",zorder=10)

# N = 101
#ax.plot(N101bqData_p, N101bqData_w, '.b', label="N=101",zorder=10)

#y_vector = np.hstack((N10bqData_w, N20bqData_w, N101bqData_w, N40bqData_w)).T
#x0_vector = np.hstack((N10bqData_p, N20bqData_p, N101bqData_p, N40bqData_p)).T
#x1_vector = np.hstack((N10bqData_p*np.log(10), N20bqData_p*np.log(20), N101bqData_p*np.log(101), N40bqData_p*np.log(40))).T

#Fit to 20 and 40
#y_vector = np.hstack((N20bqData_wLowerErrorBar, N40bqData_wUpperErrorBar)).T
#x0_vector = np.hstack((N20bqData_p, N40bqData_p)).T
#x1_vector = np.hstack((N20bqData_p*np.log(20), N40bqData_p*np.log(40))).T

#Fit to 20,40, and 101
#y_vector = np.hstack((N20bqData_wLowerErrorBar, N40bqData_wUpperErrorBar, N101bqData_w)).T
#x0_vector = np.hstack((N20bqData_p, N40bqData_p, N101bqData_p)).T
#x1_vector = np.hstack((N20bqData_p*np.log(20), N40bqData_p*np.log(40),N101bqData_p*np.log(101))).T
#Amatrix = np.vstack((x0_vector,x1_vector)).T

###########
#QPizza Graph
###########
#
###Pre-code Fix Data
###########
##N=21
#p_N21 = np.array([0.3869,  0.4573,  0.4975,  0.5678,  0.608,   0.6784,  0.7186,  0.7889,  0.8291,  0.8995,  0.9397])
#w_N21 = np.array([5.5273,   6.5323,   7.1354,   8.1404,   8.7434,   9.7485,  10.3515,  11.3566,  11.9596,  12.9646,  13.5677])
#ax.plot(p_N21, w_N21, '.b', label="Fitting",zorder=10)
#
##N=31
#p_N31 = np.array([0.2362,  0.2864,  0.4975,  0.5477,  0.598,   0.6482,  0.7085,  0.7588,  0.809,   0.8593,  0.9095,  0.9598,  0.9698])
#w_N31 = np.array([3.7182,   4.5222,   7.9394,   8.7434,   9.5475,  10.3515,  11.3566,  12.1606,  12.9646,  13.7687,  14.5727,  15.3768,  15.5778])
#ax.plot(p_N31, w_N31, '.b', label="Fitting",zorder=10)
#
##N=41
#p_N41 = np.array([0.1156,  0.3367,  0.4874,  0.5578,  0.6281,  0.6382,  0.7085,  0.7789,  0.8492,  0.8593,  0.9196,  0.9296,  1.   ])
#w_N41 = np.array([1.9091,   5.7283,   8.3414,   9.5475,  10.7535,  10.9545,  12.1606,  13.3667,  14.5727,  14.7737,  15.7788,  15.9798,  17.1859])
#ax.plot(p_N41, w_N41, '.b', label="Fitting",zorder=10)
#
##N=101
#p_N101 = np.array([0.0754,  0.2764,  0.2864,  0.4874,  0.4975,  0.5075,  0.6884,  0.6985,  0.7085,  0.7186,  0.7286,  0.8894,  0.8995,  0.9095,  0.9196,  0.9296,  0.9397,  0.9497])
#w_N101 = np.array([1.5071,   5.7283,   5.9293,  10.1505,  10.3515,  10.5525,  14.3717,  14.5727,  14.7737,  14.9747,  15.1758,  18.5929,  18.7939,  18.9949,  19.196,   19.397,   19.598,   19.799])
#ax.plot(p_N101, w_N101, '.b', label="Fitting",zorder=10)

####New Data
############
##N=21
#p_N21 = np.array([ 0.2965,  0.3668,  0.4372,  0.5075,  0.5779,  0.6181,  0.6482,  0.6884,  0.7588,  0.8291,  0.8995,  0.9397,  0.9698])
#w_N21 = np.array([4.1202,   5.1253,   6.1303,   7.1354,   8.1404,   8.7434,   9.1455,   9.7485,  10.7535,  11.7586,  12.7636,  13.3667,  13.7687])
##ax.plot(p_N21, w_N21, '.b', label="Fitting",zorder=10)
#
##N=31
#p_N31 = np.array([0.2362,  0.397 ,  0.4472,  0.5578,  0.608 ,  0.6583,  0.7186,  0.7688,  0.8191,  0.8291,  0.8693,  0.8794,  0.9296,  0.9799,  0.9899])
#w_N31 = np.array([3.7182,   6.3313,   7.1354,   8.9444,   9.7485,  10.5525,  11.5576,  12.3616,  13.1657,  13.3667,  13.9697,  14.1707,  14.9747,  15.7788,  15.9798])
##ax.plot(p_N31, w_N31, '.b', label="Fitting",zorder=10)
#
##N=41
#p_N41 = np.array([0.206 ,  0.2864,  0.3769,  0.4573,  0.5377,  0.5477,  0.6181,  0.6281,  0.6985,  0.7085,  0.7889,  0.799 ,  0.8693,  0.8794,  0.9497,  0.9598,  0.9698])
#w_N41 = np.array([3.5172,   4.9242,   6.5323,   7.9394,   9.3465,   9.5475,  10.7535,  10.9545,  12.1606,  12.3616,  13.7687,  13.9697,  15.1758,  15.3768,  16.5828,  16.7838,  16.9848])
##ax.plot(p_N41, w_N41, '.b', label="Fitting",zorder=10)
#
##N=101
#p_N101 = np.array([0.2462,  0.3367,  0.3467,  0.4372,  0.4472,  0.5377,  0.5477,  0.6382,  0.6482,  0.7286,  0.7387,  0.7487,  0.8291,  0.8392,  0.8492,  0.8593])
#w_N101 = np.array([5.3263,   7.3364,   7.5374,   9.5475,   9.7485,  11.7586,  11.9596,  13.9697,  14.1707,  15.9798,  16.1808,  16.3818,  18.1909,  18.3919,  18.5929,  18.7939])
##ax.plot(p_N101, w_N101, '.b', label="Fitting",zorder=10)

###Resubmit Data
###########
#N=21
p_N21 = np.array([ 0.2462,0.3568,0.4171,0.4673,0.5276,0.5879,0.6382,0.6985,0.7487,0.7588,0.809,0.8593,0.8693,0.9196,0.9296,0.9698,0.9799])
w_N21 = np.array([3.9192,5.7283,6.7333,7.5374,8.5424,9.5475,10.3515,11.3566,12.1606,12.3616,13.1657,13.9697,14.1707,14.9747,15.1758,15.7788,15.9798])
#ax.plot(p_N21, w_N21, '.b', label="Fitting",zorder=10)

#N=25
p_N25 = np.array([ 0.1055,0.1859,0.2663,0.3367,0.4171,0.4975,0.5678,0.5779,0.6482,0.6583,0.7286,0.7387,0.799,0.809,0.8191,0.8794,0.8894,0.9497,0.9598,0.9698])
w_N25 = np.array([1.7081,3.1152,4.5222,5.7283,7.1354,8.5424,9.7485,9.9495,11.1556,11.3566,12.5626,12.7636,13.7687,13.9697,14.1707,15.1758,15.3768,16.3818,16.5828,16.7838])
#ax.plot(p_N25, w_N25, '.b', label="Fitting",zorder=10)

#N=31
p_N31 = np.array([0.0553,0.206,0.3467,0.3568,0.4874,0.4975,0.5075,0.6281,0.6382,0.6482,0.6583,0.7688,0.7789,0.7889,0.799,0.809,0.9095,0.9196,0.9296,0.9397,0.9497,0.9598])
w_N31 = np.array([0.904,3.7182,6.3313,6.5323,8.9444,9.1455,9.3465,11.5576,11.7586,11.9596,12.1606,14.1707,14.3717,14.5727,14.7737,14.9747,16.7838,16.9848,17.1859,17.3869,17.5879,17.7889])
#ax.plot(p_N31, w_N31, '.b', label="Fitting",zorder=10)

#N=41
p_N41 = np.array([0.4472,0.4573,0.4673,0.4774,0.4874,0.4975,0.5075,0.5176,0.5276,0.5377,0.5477,0.5578,0.5678,0.5779,0.5879,0.598,0.608,0.6181,0.6281,0.6382,0.6482,0.6583,0.6683,0.6784,0.6884,0.6985,0.7085,0.7186,0.7286])
w_N41 = np.array([8.9444,9.1455,9.3465,9.5475,9.7485,9.9495,10.1505,10.3515,10.5525,10.7535,10.9545,11.1556,11.3566,11.5576,11.7586,11.9596,12.1606,12.3616,12.5626,12.7636,12.9646,13.1657,13.3667,13.5677,13.7687,13.9697,14.1707,14.3717,14.5727])
#ax.plot(p_N41, w_N41, '.b', label="Fitting",zorder=10)

#N=101
p_N101 = np.array([0.206,0.2462,0.3568,0.397,0.4372,0.4774,0.5075,0.5477,0.5879,0.6281,0.6583,0.6683,0.6985,0.7085,0.7387,0.7789])
w_N101 = np.array([5.1253,6.1303,8.9444,9.9495,10.9545,11.9596,12.7636,13.7687,14.7737,15.7788,16.5828,16.7838,17.5879,17.7889,18.5929,19.598])
#ax.plot(p_N101, w_N101, '.b', label="Fitting",zorder=10)

#N=301
p_N301 = np.array([0.1457,0.2161,0.2864,0.3568,0.3769,0.4271,0.4472,0.4774,0.4975,0.5176,0.5477,0.5678,0.5879,0.6181,0.6382])
w_N301 = np.array([4.5222,6.7333,8.9444,11.1556,11.7586,13.3667,13.9697,14.9747,15.5778,16.1808,17.1859,17.7889,18.3919,19.397,20])
#ax.plot(p_N301, w_N301, '.b', label="Comparison",zorder=10)

#N=1001
p_N1001 = np.array([0.0251,0.1357,0.1457,0.2462,0.2563,0.2663,0.3568,0.3668,0.3769,0.3869,0.4673,0.4774,0.4874,0.4975,0.5075])
w_N1001 = np.array([0.904,5.1253,5.5273,9.3465,9.7485,10.1505,13.5677,13.9697,14.3717,14.7737,17.7889,18.1909,18.5929,18.9949,19.397])
#ax.plot(p_N1001, w_N1001, '.b', label="Comparison",zorder=10)




y_vector = np.hstack((w_N21, w_N25, w_N31, w_N41, w_N101)).T
x0_vector = np.hstack((p_N21, p_N25, p_N31, p_N41, p_N101)).T
x1_vector = np.hstack((p_N21*np.log(21), p_N25*np.log(25), p_N31*np.log(31), p_N41*np.log(41), p_N101*np.log(101))).T
Amatrix = np.vstack((x0_vector,x1_vector)).T



print "y_vector = ", y_vector
print "x0_vector = ", x0_vector
print "x1_vector = ", x1_vector
print "Amatrix = ", Amatrix

lstsqOutput = np.linalg.lstsq(Amatrix, y_vector)

A, B = lstsqOutput[0]
residuals = lstsqOutput[1]

print "A = ", A
print "B = ", B
print "residuals = ", residuals

###########################################
#Plot N*lambda
###########################################

#L = 1000 #30
t = 1
#gamma = 9.8#np.power(10,0.935) = 8.61
#alpha = -6.08476754059#28*np.pi/3*(np.log(3)/2/np.log(2) - 1) = -6.08476754059
#beta = 42.3020279904#28*np.pi/3/np.log(2) = 42.3020279904
gamma = 100
alpha = gamma*A/t/t
beta = gamma*B/t/t

print "gamma = ", gamma
print "alpha = ", alpha
print "beta = ", beta

maxw = 21

pStartArray2 = np.linspace(0.001,1,num=1000)
wStartArray2 = np.linspace(0.01,maxw,num=1000)

grid_p2, grid_w2 = np.meshgrid(pStartArray2,wStartArray2)

#expList = [1, np.log10(20), np.log10(30), np.log10(60)] + range(2,30,2)

#expList = []
#expList = np.log10([3,5,11,13,15,25,31,35])
#expList = [np.log10(31)]
expList = [np.log10(20), np.log10(25), np.log10(30), np.log10(40), 2, 3, 4, 6, 10, 15]
#expList = np.log10([21,25,31,41,101,301,1001])
#expList = np.log10([21,25,31,41,101])
#expList = np.log10([20,30,40])
#expList = [10,15]

#print expList
L_list = [10.**i for i in expList]
#print L_list

for L_sidelength in L_list:
#    print "L = ", L_sidelength

    w_lambdaLine = pStartArray2 *t /gamma * (alpha + beta*np.log(L_sidelength))
    
    pStartArray2_plot = pStartArray2[w_lambdaLine < maxw]
    w_lambdaLine_plot = w_lambdaLine[w_lambdaLine < maxw]
    
    
    if np.abs(L_sidelength - 30.) < 1E-6:
        lineHandle, = ax.plot(pStartArray2_plot, w_lambdaLine_plot, '-', color='k', linewidth=3.0,zorder=0) #linewidth=3.0
        textSize = 11
        np.savetxt("N30data.txt", [pStartArray2.T, w_lambdaLine.T], delimiter=',',fmt='%.14e')
#        np.savetxt("N25wdata.txt", w_lambdaLine.T, delimiter=',')

    else:
        lineHandle, = ax.plot(pStartArray2_plot, w_lambdaLine_plot, '--', color='k', linewidth=1.0,zorder=0)
        textSize = 11
#        pass

    # The below 6 lines modified from http://stackoverflow.com/questions/19876882/print-string-over-plotted-line-mimic-contour-plot-labels
    if L_sidelength < 1000:
        line_string = r'$N = {0:d}$'.format(int(np.round(L_sidelength)))
    else:
        line_string = r'$N = 10^{%d}$' % (int(np.round(np.log10(L_sidelength))))

    if (np.abs(L_sidelength - 20.) < 1E-6):
        pos = [1.4*(pStartArray2_plot[0]+ pStartArray2_plot[-1])/2., 1.4*(w_lambdaLine_plot[0]+w_lambdaLine_plot[-1])/2.]

    elif (np.abs(L_sidelength - 40.) < 1E-6):
        pos = [1.25*(pStartArray2_plot[0]+ pStartArray2_plot[-1])/2., 1.25*(w_lambdaLine_plot[0]+w_lambdaLine_plot[-1])/2.]

    elif (np.abs(L_sidelength - 30.) < 1E-6):
        pos = [1.3*(pStartArray2_plot[0]+ pStartArray2_plot[-1])/2., 1.3*(w_lambdaLine_plot[0]+w_lambdaLine_plot[-1])/2.]

    elif (np.abs(L_sidelength - 25.) < 1E-6):
        pos = [1.35*(pStartArray2_plot[0]+ pStartArray2_plot[-1])/2., 1.35*(w_lambdaLine_plot[0]+w_lambdaLine_plot[-1])/2.]

    else:
        pos = [(pStartArray2_plot[0]+ pStartArray2_plot[-1])/2., (w_lambdaLine_plot[0]+w_lambdaLine_plot[-1])/2.]
    # transform data points to screen space
    xscreen = ax.transData.transform(zip(np.array([pStartArray2_plot[0],pStartArray2_plot[-1]]),np.array([w_lambdaLine_plot[0],w_lambdaLine_plot[-1]])))
    rot = np.rad2deg(np.arctan2(*np.abs(np.gradient(xscreen)[0][0][::-1])))
    ltex = ax.text(pos[0], pos[1], line_string, size=textSize, rotation=rot, ha="center", va="center",bbox = dict(ec="none", fc='1',pad=0.),zorder=1) #lineHandle.get_color() #size=9
    ltex = ax.text(pos[0], pos[1], line_string, size=textSize, rotation=rot, ha="center", va="center", color = "black",zorder=2)#size=9







#ax.text(0.5,10, "Hello",rotation=45)


#figNum += 1
#fig2 = plt.figure(figNum,facecolor="white")
#ax2 = plt.subplot()
#
#
#im = ax2.imshow(Nlambda_plot, vmin=np.min(Nlambda_plot), vmax=np.max(Nlambda_plot), interpolation='nearest',origin='lower',aspect='auto',extent=[0,plotWidth,0,plotHeight], cmap=cm)
#cbar = plt.colorbar(im)

##plt.ylim(0.,np.max(wPlotArray)*1.1)
##plt.xlim(0.,1.01)
#plt.ylim(0.,plotHeight)
#plt.xlim(0.,plotWidth)
##plt.xlabel(r'Probability of Occupation, $p$', fontsize=16)
##plt.ylabel(r'Disorder Strength, $w$', fontsize=16)
#plt.xlabel(r'$p$', fontsize=24, labelpad=-3.)
#plt.ylabel(r'$w$', fontsize=24)
##plt.title("Local Level Density", fontsize=18)
##plt.colorbar(sc)
##plt.colorbar(im)
#[i.set_linewidth(3.0) for i in ax2.spines.itervalues()]
#for tick in ax2.get_xaxis().get_major_ticks():
#    tick.set_pad(8.)
#    tick.label1 = tick._get_text1()
#for tick in ax2.get_yaxis().get_major_ticks():
#    tick.set_pad(10.)
#    tick.label1 = tick._get_text1()
#for label in ax2.yaxis.get_ticklabels():
#    label.set_verticalalignment('center')
#
#ax2.tick_params(direction="inout", length=10, width=2, colors='k', top='off', right='off', labelsize=20)
#ax2.plot(pStartArray2_plot, w_lambdaLine_plot, '-', color='k')#color='0.5'
#
#plt.tight_layout()


###########################################
#Plot P_M_noRes
###########################################

#Import Data
with np.load(inputFilename) as dataDict:
    
    infoArrayKey = dataDict["infoArrayKey"]
    infoArray=dataDict["infoArray"]
    grid_p=dataDict["grid_p"]
    grid_omega=dataDict["grid_omega"]
    P_noResGrid=dataDict["P_noResGrid"]

#Plot whole diagram

t_data = infoArray[1]
#print t_data

plotGrid = P_noResGrid
#plotGrid = -1.*np.log10(P_noResGrid)
print plotGrid

plotHeight = 21
plotWidth = 1.
cm = plt.cm.get_cmap('cool') #'hot'

#im = plt.imshow(plotGrid, interpolation='nearest', origin='lower', aspect='auto', extent=[np.min(grid_p),np.max(grid_p),np.min(grid_omega/t_data),np.max(grid_omega/t_data)], cmap=cm)
#cbar = plt.colorbar(im)
#
#cbar.outline.set_linewidth(3.0)
#cbar.ax.set_ylabel(r'$b$',size=24,rotation=0,labelpad=19,verticalalignment="center")
#cbar.ax.tick_params(direction="inout", length=7, width=2, colors='k', top='off', right='on', labelsize=16)

plt.ylim(0.,plotHeight)
plt.xlim(0.,plotWidth)
plt.xlabel(r'$p$', fontsize=24, labelpad=-3.)
plt.ylabel(r'$w$', fontsize=24)

[i.set_linewidth(3.0) for i in ax.spines.itervalues()]
for tick in ax.get_xaxis().get_major_ticks():
    tick.set_pad(8.)
    tick.label1 = tick._get_text1()
for tick in ax.get_yaxis().get_major_ticks():
    tick.set_pad(10.)
    tick.label1 = tick._get_text1()
for label in ax.yaxis.get_ticklabels():
    label.set_verticalalignment('center')

ax.tick_params(direction="inout", length=10, width=2, colors='k', top='off', right='off', labelsize=20)

plt.tight_layout()

#Highlight specific value of P_M_noRes

#Line at P_M_noRes = XXX
P_M_noRes_line = 0.012 #0.0063 #0.0042 for N=21 data; 0.0021 for N=31 data; 0.0013 for N=41 data
w_cutoff = 0.#0.75 #Use 0 for none
criterion = 1e-2 #1e-2
p5array = grid_p[np.abs((P_noResGrid - P_M_noRes_line)/P_M_noRes_line) < criterion]
w5array = (grid_omega/t_data)[np.abs((P_noResGrid - P_M_noRes_line)/P_M_noRes_line) < criterion]

#ax.plot(p5array, w5array, '.', linestyle="-", color='r',markersize=10,label="P(noRes)=%f"%(P_M_noRes_line),zorder=8)#color='0.5'

print "Datapoints for isoprobability Line:"
print p5array
print w5array

#plt.scatter(p5array, w5array, clip_on=False)



ax.legend(loc="upper left")
ax.set_axisbelow(False)

##################
#Plot band from Tianrui's phase Diagram
#################
numDataPoints = 100

pUpperArray = np.zeros(numDataPoints)
wUpperArray = np.zeros(numDataPoints)

upperBoundFile = open(upperBoundFilename,"r")

upperBoundFile.readline()

i = 0

for line in upperBoundFile:
    numericalValues = line.split()
    pUpperArray[i] = float(numericalValues[0])
    wUpperArray[i] = float(numericalValues[1])
    i += 1

###############
pLowerArray = np.zeros(numDataPoints)
wLowerArray = np.zeros(numDataPoints)

lowerBoundFile = open(lowerBoundFilename,"r")

lowerBoundFile.readline()

i = 0

for line in lowerBoundFile:
    numericalValues = line.split()
    pLowerArray[i] = float(numericalValues[0])
    wLowerArray[i] = float(numericalValues[1])
    i += 1


#ax.plot(pLowerArray, wLowerArray, linestyle="-", color='g',zorder=10)#color='0.5'
#ax.plot(pUpperArray, wUpperArray, linestyle="-", color='g',zorder=10)#color='0.5'

figureFilename = "/Users/jtcantin/Documents/phaseDiagram_N30_alpha3_LevitovAnalysis.eps"
#fig.savefig(figureFilename, format='eps', dpi=1200)
fig.savefig(figureFilename, format='eps', dpi=150)
#fig.savefig(figureFilename, format='pdf', dpi=300)


plt.show()




