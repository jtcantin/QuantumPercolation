//
//  main.cpp
//  disorders
//
//  Created by Tianrui Xu on 2015-05-03.
//  Copyright (c) 2015 TianruiXu. All rights reserved.
//


#include <iostream>
#include <vector>
#include <stdlib.h>
#include <Eigen/Dense>
#include <time.h>
#include <Eigen/Eigenvalues>
#include <complex>
#include <fstream>
#include <sstream>
#include <string>
#include <cmath>
#include "matrix_set.h"
#include "quantumPercolation.h"

#define I complex<double>(0.0,1.0);
const double pi=3.141592653589793238462643383279502884197169399375105820974944;
const double eps=8.85419*pow(10.0,-12);
const double h=6.62606957*pow(10.0,-34);
const double hbar=1.054571726*pow(10.0,-34);

using namespace std;
using namespace Eigen;
using Eigen::MatrixXd;

int zhop, size, occnum;
double Gamma;
double range,pvac;
string occfile="rd3do",rndfile="rd3dw",outfile="rd3d";

int main(int argc, const char * argv[])
{
    /** %%%%%%%%%%%%%%%%%%%% INITIALIZING %%%%%%%%%%%%%%%%%%%% */
    const char *dis=argv[argc-1];
    //string c="dis_in.txt";
    const char* inputFile = argv[1];
    string line;
    int dum=0;
    VectorXd a;
    ifstream input (inputFile);
    if (input.is_open())
    {
        while (getline(input,line))
        {
            if (line[0]=='!'){dum=dum+1;}
            else
            {
                if (dum==1)
                {
                    size=atoi(line.c_str());
                    occfile=occfile.append(line.c_str());
                    rndfile=rndfile.append(line.c_str());
                    outfile=outfile.append(line.c_str());
                    outfile=outfile.append("_");                    
                }
                else if (dum==2)
                {
                    if (line.compare("Long")==0)
			{
			    range=size*2.0;
			    outfile=outfile.append("LR");
			    outfile=outfile.append("_"); 
			}
                    else 
			{
			    range=atoi(line.c_str());
			    outfile=outfile.append(line.c_str());
			    outfile=outfile.append("NN_"); 
			}
                }
                else if (dum==3){Gamma=atof(line.c_str());}
                else if (dum==4){zhop=atoi(line.c_str());}
                else if (dum==5)
                {
                    pvac=atoi(line.c_str());
                    occfile=occfile.append(line.c_str());
                    rndfile=rndfile.append(line.c_str());
                    outfile=outfile.append(line.c_str());
                    outfile=outfile.append("_");
                }

/*                else if (dum==6)
                {
                    cout<<'\t'<<dum<<endl;
                    occfile=occfile.append(line.c_str());
                    rndfile=rndfile.append(line.c_str());
                }
*/
            }
        }
        input.close();
    }
    else {cout<<"Unable to open file: "<<inputFile<< " \n";};
    
    occfile=occfile.append(dis);
    rndfile=rndfile.append(dis);
    outfile=outfile.append(dis);
    
    occfile=occfile.append(".txt");
    rndfile=rndfile.append(".txt");
    
    cout<<"lattice size = "<<size<<endl;
    cout<<"range = "<<range<<endl;
    cout<<"decay = "<<Gamma<<endl;
    cout<<"symmetrical? "<<zhop<<endl;
    cout<<"percent of vacancy: "<<pvac<<endl;
    cout<<"occupation file: "<<occfile<<endl;
    cout<<"on-site energy file: "<<rndfile<<endl;
    /** %%%%%%%%%%%%%%%%%%%% END OF INITIALIZATION %%%%%%%%%%%%%%%%%%%% */

    Hamiltonian C;
    double* H;
    C.Hami(size, occfile, rndfile, range, zhop, Gamma, H, occnum);
    double* eigStateMatrix = new double [occnum*occnum]; //For Lapack, but put it here so program crashes sooner rather than later if there is not enough memory

//Lapack
    int numEigvals;
    double* eigvals;
    int presInt = 16;
    eigvals = new double [occnum];
            
    dsyevrEigstatesInterface(H, occnum, &numEigvals, eigvals, eigStateMatrix);
    cout << "NumEvals: " << numEigvals << endl;
    cout << setprecision(presInt);
    
    //Map array type to Eigen type -- Eval
    cout << "Eigenvalues mapping..." << endl;
    Map<VectorXd> Eval_dym(eigvals,numEigvals);
    cout << "Eigenvalues recording..." << endl;
    ofstream evalout;
    double sumLvSpacing=0.0;
    evalout.open((outfile+"_Eval.txt").c_str());
    evalout<< setprecision(presInt);
    for (int ieval=0; ieval<numEigvals; ieval++)
    {
        evalout<<Eval_dym[ieval]<<endl;
        if(ieval<numEigvals-1)
        {
            sumLvSpacing=sumLvSpacing+Eval_dym[ieval+1]-Eval_dym[ieval];
        }
    }
    double t_H=1./(sumLvSpacing/double(numEigvals-1.));
    evalout<<"#t_H = \n"<<t_H<<endl;
    cout<<"#t_H = \n"<<t_H<<endl;
    
    evalout.close();
    
    //C.saveMatrixtxt(outfile+"_Eval.txt",Eval_dym);
    
    
    //Map array type to Eigen type -- Evec
    cout << "Eigenvectors mapping..." << endl;
    Map<MatrixXd> Evec_dym(eigStateMatrix,numEigvals,numEigvals);
    cout << "Done Eigenvectors Mapping, start IPR calculations" << endl;
    
    /** %%%%%%%%%%%%%%%%%%%% END OF DIAGONALIZATION %%%%%%%%%%%%%%%%%%%% */
    
    /** %%%%%%%%%%%%%%%%%%%% Calculate IPR %%%%%%%%%%%%%%%%%%%% */
    MatrixXd IPRmatrix;
    RowVectorXd IPRvector;
    MatrixXd outputMat(Evec_dym.rows(), 2);
    IPRmatrix = Evec_dym.array() * Evec_dym.array() * Evec_dym.array() * Evec_dym.array();
    IPRvector = IPRmatrix.colwise().sum();
    
    outputMat << Eval_dym, IPRvector.transpose();
    
    //    cout << outputMat << endl;
    
    ofstream IPRfile;
    IPRfile.open((outfile+"_IPR"+".txt").c_str());
    IPRfile.precision(presInt);
    //    IPRfile<< setprecision(presInt);
    IPRfile<<scientific;
    IPRfile << "#Energy, IPR" << endl;
    IPRfile << outputMat << endl;
    IPRfile.close();
    
    cout << "Done IPR calc" << endl;
    
    cout<<"done! \n";
    
    delete [] eigStateMatrix;
    delete [] eigvals;
    delete [] H;
    
    
}
