#This file calculates the input files and tells you what to run to start the calculations.
# NOTE: you need python 2.7 and numpy. 
# You also need these in the directory:
#   rand_dis_fcn.py 
#   QmPerc_LINUX_TRX

import sys
import os
import datetime
import numpy as np
import rand_dis_fcn as rdf


runNum = 1 #Says what folder to store input files in: run[runNum]
numThreads = 4 #Number of threads to use. Most nodes on Fano have at most 12 cores.

dipolar = False #Flag for anisotropy. 
                #If False, isotropic. 
                #If True, the anisotropic hopping of Cantin, Xu, and Krems, Phys Rev B 2018
alphaList = [0,1.5,np.inf] #Range exponent. Can be 0, a positive real number, or np.inf
qList = [0,99]      #q is the fraction of vacancies (ie. 100*(1-p), where p is the filling fraction)
                 #q MUST be an integer
wList = [0,16.5] #w is the disorder strength.
Nlist = [11] #N is the system side-length (Number of sites = N^3)
numDisorders = 3 #The number of disorder realizations to be run, you may need a lot (ie. hundreds), depending on what you are calculating

#q=25,40 transtion line: wList = [0,2,4,5,6,7,8,8.5,9,9.5,10,10.5,11,12,13,15,20]
#q=0 transition line (tentative): [1,5,8,10,12,13,14,15,15.5,16,16.5,17,18,19,20,22,24,28]
#w=4 transition line: [90, 80, 70, 60, 55, 50, 45, 40, 35, 30, 20, 10, 0]
#Initial phase diagram spread: N=30, qList = [90, 75, 50, 25, 0], wList = [0, 5, 10, 15, 20], numDisorders = 3
#Second phase diagram spread: N=30, qList = [95, 82, 62, 37, 12], wList = [0, 2.5, 7.5, 12.5, 17.5], numDisorders = 3
#Additional points:
#q: [95,3,0]
#w: [20,0,0.5]

def dis_in_make(N,rng,q,filename):
    
    if np.isinf(rng):
        numNN = 1
        gamma = 3
    else:
        numNN = "Long"
        gamma = rng
    
    dis_inFile = open(filename,'w')

    dis_inFile.write("!Size -- has to be an integer, the actual size of the system is size^3\n")
    dis_inFile.write("{0}\n".format(N))
    
    dis_inFile.write("!Range -- xNN/ 'Long'\n")
    dis_inFile.write("{0}\n".format(numNN))

    dis_inFile.write("!Gamma -- tunnelling amplitude ~d^(-Gamma), double\n")
    dis_inFile.write("{0:.16F}\n".format(gamma))

    dis_inFile.write("!Z-hop -- 0: t_Z=t; 1: t_Z=2t\n")
    if dipolar == True:
        dis_inFile.write("1\n")
    else:
        dis_inFile.write("0\n")

    dis_inFile.write("!Percent of Vacancy -- percentage, i.e. x%\n")
    dis_inFile.write("{0}\n".format(q))

    dis_inFile.write("!end of the input file\n")
    dis_inFile.write("\n")

    dis_inFile.close()

bigRunDir = "run{0}".format(runNum)

bashFilename = "%s/runCode%d.sh" % (bigRunDir, runNum)

bashFile = open(bashFilename, 'w')

tmpDir = "/tmp/ME/QPerc/run%d/" % runNum

#Make the code exceutable
os.system("chmod 744 QmPerc_LINUX_TRX")

#BASH: Move relevant files to tmp directory
bashFile.write("cp -r * %s \n" % tmpDir)
bashFile.write("cd %s \n" % tmpDir)
bashFile.write("\n")

#BASH: Verify current directory
bashFile.write("echo $PWD \n")
bashFile.write("\n")

#BASH: Set and display number of threads
bashFile.write("export OMP_NUM_THREADS=%d \n" % numThreads)
bashFile.write("export MKL_NUM_THREADS=%d \n" % numThreads)
bashFile.write("\n")

bashFile.write("echo OMP_NUM_THREADS \n")
bashFile.write("echo $OMP_NUM_THREADS \n")
bashFile.write("\n")
bashFile.write("echo MKL_NUM_THREADS \n")
bashFile.write("echo $MKL_NUM_THREADS \n")
bashFile.write("\n")

#Execution Commands
#N = 30
#q = 60
#w = 13
#alpha = 3.2

for alpha in alphaList:
    for q in qList:
        for w in wList:
            for N in Nlist:

                if np.isinf(alpha):
                    rng = "TB"
                else:
                    integerPart = int(alpha)
                    decimalPart = alpha - integerPart
                    rng = "{0}-{1}".format(integerPart, str(decimalPart)[2:])
                if dipolar==True:
                    hopType = "anisotropic"
                else:
                    hopType = "isotropic"
                #Make disorder files and dataDir
                currentTimeString = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
                if np.abs((int(w) - w)) < 1E-16:
                    dataDirStem = "data_N{0:03d}_q{1:02d}_w{2:03d}_r{3}_{4}_{5}".format(N,q,w,rng,hopType,currentTimeString)
                else:
                    dataDirStem = "data_N{0:03d}_q{1:02d}_w{2:03.2f}_r{3}_{4}_{5}".format(N,q,w,rng,hopType,currentTimeString)
                        
                        
                dataDir = "{0}/{1}".format(bigRunDir,dataDirStem)

                wmin = -w/2.
                wmax = w/2.

                rdf.rand_occ(N,q,numDisorders,dataDir) #<-- random occupied site number
                rdf.rand_onsite(N, q, wmin, wmax, numDisorders, dataDir) #<-- random on-site energy

                #Make input file
                inputFile = "dis_in_N{0}_q{1}_w{2}_r{3}.txt".format(N, q, w, rng)
                inputFileLoc = "{4}/dis_in_N{0}_q{1}_w{2}_r{3}.txt".format(N, q, w, rng, dataDir)
                #inputFile = "dis_in_N{0}_q{1}.txt".format(N, q)

                dis_in_make(N,alpha,q,inputFileLoc)

                #Copy executable files to dataDir
                os.system("cp QmPerc_LINUX_TRX {0}/".format(dataDir))

                #BASH: cd into dataDirStem
                bashFile.write("cd %s \n" % dataDirStem)
                
                bashFile.write("echo \"-----------------Starting calculations for {0}---------------------\"\n".format(dataDirStem))
                bashFile.write("\n")

                #BASH: Run calculations
                for disNum in range(0,numDisorders):
                    bashFile.write("echo \"----------------\" \n")
                    bashFile.write("echo \"N%d q%d w%d r%s Dis%d\" \n" % (N, q, w, rng, disNum) )
                    bashFile.write("/usr/bin/time ./QmPerc_LINUX_TRX {0} {1} \n".format(inputFile, disNum))
                    bashFile.write("\n")

                bashFile.write("echo \"-----------------Calculations for {0} completed---------------------\"\n".format(dataDirStem))
                bashFile.write("\n")

                #BASH: cd back out of dataDir
                bashFile.write("cd .. \n")
                bashFile.write("\n")

##################################

bashFile.write("echo \"-----------------All calculations completed---------------------\"\n")
bashFile.write("\n")

#BASH: Copy everything to data root directory
dataRootDir = "/tmp/ME/data/"
#dataStorageDir = dataRootDir + dataDir


bashFile.write("cp -r /tmp/ME/QPerc/run{0}/* {1} \n".format(runNum, dataRootDir))
bashFile.write("\n")

bashFile.write("mv {0}runCode{1}.sh {0}runCode{1}_{2}.sh \n".format(dataRootDir, runNum, currentTimeString))
bashFile.write("\n")

bashFile.write("echo \"-------------------Copying completed-----------------------\"\n")
bashFile.write("\n")
         
#BASH: Email saying the job is done
#bashFile.write("echo \"Run{0} has finished.\" | mail -s \"Calculation Finished\" jtcantin@chem.ubc.ca \n".format(runNum))

bashFile.close()

#Make the bash script executable
os.system("chmod 744 {0}".format(bashFilename))


print "Files created."
print "Execution command (run this on a Fano node):"
print "mkdir -p {}".format(dataRootDir)
print "mkdir -p /tmp/ME/QPerc/run{0}".format(runNum)
print "cd ./run{0}".format(runNum)
print "nohup ./runCode{0}.sh &> {1}log{2}.txt &".format(runNum,tmpDir,currentTimeString)


