#
#  disDilLattice.py
#
#
# Created by Joshua Tyler Cantin on 2015-05-28.
#
#To run: python disDilLattice.py N q w occupationArrayFilename onsiteEnergyArrayFilename

import numpy as np
import numpy.ma as ma
import sys
import datetime
import os

np.set_printoptions(threshold=10000,linewidth=2000,precision=16,suppress=False)

#Define a function to create conversion arrays from index to coordinates
def convArrays(dim,lengths):
    if (dim == 3):
        if len(lengths) != 3:
            sys.exit("ERROR: Need 3 lengths for 3D")

        Nx = lengths[0]
        Ny = lengths[1]
        Nz = lengths[2]

        indToCoorArray = []
        coorToInd3DArray = np.zeros((Nx,Ny,Nz))
        
        ind = 0
        
        for k in range(0,Nz):
            for j in range(0,Ny):
                for i in range(0,Nx):
                    indToCoorArray.append((i,j,k))
                    coorToInd3DArray[i,j,k] = ind

                    ind += 1

#        print coorToInd3DArray
#        print indToCoorArray
#        print Nx, Ny, Nz

        return coorToInd3DArray, indToCoorArray

    else:
        sys.exit("ERROR: Dim = %d not implemented" % dim)

#Parameters
t = 1.                  #Hopping parameter, Leave this alone.
alpha = 0.              #Range exponent
type = "anisotropic"    #Must be one of these: isotropic, anisotropic, TB
dipolarCoeff = 1.       #Leave this alone

#numTimeSteps = 102
#ti = 1E0
#tf = 1E10
#t_type = "log" #"lin" or "log"
##time_1Darray = np.linspace(0,1,numTimeSteps)
#time_1Darray = np.append(0,np.logspace(np.log10(ti),np.log10(tf),numTimeSteps-1))
#
#L_thresh = 0.9

#Read in files
N = int(sys.argv[1])
q_value = int(sys.argv[2])
w_value = float(sys.argv[3])
occupationArrayFilename = sys.argv[4]
onsiteEnergyArrayFilename = sys.argv[5]

today = datetime.date.today()
dateString = datetime.datetime.today().strftime("%Y%m%d_%H_%M_%S")

outputDir = "./pythonOutput/"
os.system("mkdir -p "+outputDir)
generic_filename = "_N{0:03d}_q{1:02d}_w{2:05.2f}_{3}_r{4:07.3f}_{5}.txt".format(N,q_value,w_value,type,alpha,dateString)

occupationArrayFile = open(occupationArrayFilename, 'r')

tester = 0
for line in occupationArrayFile:
    if (line[0] == "#") or (line.strip() == ""):
        continue
    
    if tester > 0:
        sys.exit("ERROR: More than one uncommented line encountered.")

    tmpArray = map(int, line.split())
    nSitesOc, occupationArray = tmpArray[0], tmpArray[1:]

#    print nSitesOc
#    print occupationArray
#    q_value = int(nSitesOc/(N**3))

    tester += 1

occupationArrayFile.close()

onsiteEnergyArrayFile = open(onsiteEnergyArrayFilename, 'r')

print " "
print " "

tester = 0
for line in onsiteEnergyArrayFile:
    if (line[0] == "#") or (line.strip() == ""):
        continue
    
    if tester > 0:
        sys.exit("ERROR: More than one uncommented line encountered.")

    nSitesEng = int(line.split()[0])
    onsiteEnergyArray = map(float, line.split()[1:])


#    print nSitesEng
#    print onsiteEnergyArray

    tester += 1

#print np.min(onsiteEnergyArray)

onsiteEnergyArrayFile.close()

if nSitesOc != nSitesEng:
    sys.exit("ERROR: Number of sites in the two files do not match.")

#Build Conversion arrays
print "Side Length: %d" % N
print "Lattice Size: %d" % N**3
print "Number of Occupied Sites: %d" % nSitesOc

coorToInd3DArray, indToCoorArray = convArrays(3,(N,N,N))

print "Building Hamiltonian."

#Build Hamiltonian
zHatVec = np.array([0.,0.,1.])

#Faster Hamiltonian Calc
# hami2DArray = np.zeros((nSitesOc,nSitesOc))

hamiDiag2Darray = np.diag(onsiteEnergyArray)


indToCoorNPArray=np.array(indToCoorArray)
iInd2Darray, jInd2Darray = np.meshgrid(occupationArray,occupationArray,copy=False,indexing="ij")
iVec3Darray = np.array(indToCoorNPArray[iInd2Darray.astype(int)])#.flatten().tolist()
jVec3Darray = np.array(indToCoorNPArray[jInd2Darray.astype(int)])

diffVec3Darray = iVec3Darray-jVec3Darray
dist2Darray = np.linalg.norm(diffVec3Darray, axis=2)


if type == "isotropic":
    #Assign element
    hamiOffDiag2Darray = t/(dist2Darray**alpha)

elif type == "TB": #Then Tight Binding model
    hamiOffDiag2Darray = np.zeros((nSitesOc,nSitesOc))
    hamiOffDiag2Darray[dist2Darray < 1.001] = t

elif type == "anisotropic":
    rDotz2Darray = np.tensordot(diffVec3Darray,zHatVec,axes=([2],[0]))
    # print rDotz2Darray.shape
    cos2Theta2Darray = (rDotz2Darray/dist2Darray)**2
    hamiOffDiag2Darray = dipolarCoeff * (1-3*cos2Theta2Darray) / (dist2Darray**alpha)

else:
    sys.exit("ERROR: Invalid Calculation type")
    
np.fill_diagonal(hamiOffDiag2Darray,0.)

hami2DArray = hamiOffDiag2Darray+hamiDiag2Darray

# print hami2DArray.shape


#Original Hamiltonian calc
# hami2DArrayBackUp = np.zeros((nSitesOc,nSitesOc))
# for i in range(0, nSitesOc):
    # for j in range(0, nSitesOc):
        # if i == j:
            # hami2DArrayBackUp[i,j] = onsiteEnergyArray[i]
        
        # else:
            # #Get site coordinates
            # iVec = np.array(indToCoorArray[occupationArray[i]])
            # jVec = np.array(indToCoorArray[occupationArray[j]])
            
            # #Get distance between sites
            # diffVec = iVec - jVec
            # dist = np.linalg.norm(diffVec)
            
# #            if i==13:
# #                print i
# #                print j
# #                print iVec
# #                print jVec
# #                print dist

            # if type == "isotropic":
                # #Assign element
                # hami2DArrayBackUp[i,j] = t/(dist**alpha)
            
            # elif type == "TB": #Then Tight Binding model
                # if (dist < 1.001): #True if nearest neighbour
                    # hami2DArrayBackUp[i,j] = t
# #                    print "triggered"
            # elif type == "anisotropic":
                # rDotz = np.dot(diffVec,zHatVec)
                # cosTheta = rDotz/dist #Note that zHatVec has length 1.
                # cos2Theta = cosTheta**2
                # hami2DArrayBackUp[i,j] = dipolarCoeff * (1-3*cos2Theta) / (dist**alpha)
            # else:
                # sys.exit("ERROR: Invalid Calculation type")

# print "comparison:"
# print np.max(np.abs(hami2DArrayBackUp-hami2DArray))
                
                
print "Hamiltonian built."
print "Diagonalizing..."
#np.savetxt("test.csv",hami2DArray,delimiter=",")
#print hami2DArray
#print np.max(np.abs(hami2DArray.T - hami2DArray))
#print indToCoorArray

#Diagonalize the Hamiltonian
#eval, evec = np.linalg.eig(hami2DArray)
eval, evec = np.linalg.eigh(hami2DArray)

eval_srtd = np.sort(eval)

#sort the eigenvectors, so that they are in order of increasing energy
evec_srtd = np.copy(evec[:,eval.argsort()])

print "Eigenvalues and Eigenvectors calculated and sorted."

#print " "
#print "Eigenvalues:"
#for eval_item in eval_srtd:
#    print eval_item

eigvalFilename = "eigVals"+generic_filename
np.savetxt(outputDir+eigvalFilename,eval_srtd,delimiter=',')
print "Eigenvalues saved to :", eigvalFilename

eigvecFilename = outputDir+"eigVecs"+generic_filename
eigvecFile = open(eigvecFilename,'w')
eigvecFile.write("# Site label: x_coor, y_coor, z_coor, C_1, C_2, ... C_N where _? refers to eigenstate label.\n")
# eigvecFile.write("# Site label, l, defined as l = x+Nx*(y+Ny*z) for point (x,y,z)\n")
eigvecFile.write("# Values calculated in Python using np.linalg.eigh\n")
for i in range(0,evec_srtd[:,0].size):
    eigvecFile.write("{0}: ".format(i))
    x_val,y_val,z_val = indToCoorArray[occupationArray[i]]
    eigvecFile.write("{0} {1} {2} ".format(x_val,y_val,z_val))

    for j in range(0,evec_srtd[0].size):
        eigvecFile.write("%.15E " % evec_srtd[i,j])
                    
    eigvecFile.write("\n") 

#np.savetxt(eigvecFilename,eval_srtd,delimiter=',')
print "Eigenvectors saved to :", eigvecFilename

# print "!!!!!!!!!!!!!!Eigenvectors NOT saved!!!!!!!!!!!!!!!!!!!"

####################################################################################
#Calculate IPR
####################################################################################

IPRarray = np.sum(np.power(evec_srtd,4),axis=0) #coefficients are real-valued
IPRFilename = outputDir+"IPR"+generic_filename
IPRFile = open(IPRFilename,'w')
IPRFile.write("#Energy, IPR\n")
for iter in range(IPRarray.size):
    IPRFile.write("{0: .16E} {1: .16E}\n".format(eval_srtd[iter],IPRarray[iter]))

IPRFile.close()
print "IPR values saved to :", IPRFilename
                  

#####################################################################################
##Calculate dynamics
#####################################################################################
#print "Calculating Dynamics."
#
#initialStateVector = np.zeros(nSitesOc,dtype=np.complex_)
#centreSiteCoor = (N-1)/2
#centreSiteIndex = int(np.nonzero(occupationArray==(coorToInd3DArray[centreSiteCoor,centreSiteCoor,centreSiteCoor]))[0][0]) #Need index of basis, which is based on the occupation array
#initialStateVector[centreSiteIndex] = 1.
#
#
##Transform to eigenstate basis
#eigStateInitialStateVector = np.dot(evec_srtd.conj().T,initialStateVector)
#
##Set up time propagator tensor (eigenbasis,timesteps)
#exponent_2Darray = np.outer(eval_srtd,time_1Darray)
#timePropTensor_2Darray = np.exp(-1.j*exponent_2Darray)
#
## Propagate in time
#timePropd_2Darray = (timePropTensor_2Darray.T * eigStateInitialStateVector).T
#
##Convert back to site basis
#timePropd_2Darray = np.dot(evec_srtd,timePropd_2Darray)
#
## print np.sum(np.absolute(timePropd_2Darray)**2,axis=0)
## print timePropd_2Darray.shape
#numSites = eval_srtd.size
#wvfcnProb_2Darray = (np.absolute(timePropd_2Darray))**2
#wvfcnArg_2Darray = np.angle(timePropd_2Darray)
#
#for iter in range(numTimeSteps):
#    dynamFilename = outputDir+"dynam_{0}".format(iter)+generic_filename
#    dynamFile = open(dynamFilename,'w')
#    timeVal = time_1Darray[iter]
#    for jiter in range(numSites):
#        x_val,y_val,z_val = indToCoorArray[occupationArray[jiter]]
#        # x_val,y_val,z_val = indToCoorArray[jiter]
#        dynamFile.write("{0:.16e}\t{1:d}\t{2:d}\t{3:d}\t{4:d}\t{5:.16e}\t{6:.16e}\n".format(timeVal,jiter,x_val,y_val,z_val,wvfcnProb_2Darray[jiter,iter],wvfcnArg_2Darray[jiter,iter]))
#    dynamFile.close()
#
#
#
#####################################################################################
##Calculate observables
#####################################################################################
#print "Calculating Observables."
#
##Calculate IPR
#IPR_2Darray = np.sum(np.absolute(timePropd_2Darray)**4,axis=0)
#
##print IPR_2Darray
#
##Calculate <r_vec>
#
#centreVec_1Darray = np.array([centreSiteCoor,centreSiteCoor,centreSiteCoor])
#
#indToCoorNPArray=np.array(indToCoorArray)
#
#ind2Darray = np.tile(occupationArray,(numTimeSteps,1)).T
#vec3Darray = np.array(indToCoorNPArray[ind2Darray.astype(int)])
#
#expectTerms_3Darray =  timePropd_2Darray.conj().T*timePropd_2Darray.T*np.swapaxes(vec3Darray,0,2)
#expectR_2Darray = np.sum(expectTerms_3Darray,axis=2)
#expectRcentred_2Darray = np.real((expectR_2Darray.T - centreVec_1Darray).T)
#
##Calculate Std Dev
#RsqdProb_3Darray = timePropd_2Darray.conj().T*timePropd_2Darray.T*(np.swapaxes(vec3Darray,0,2)**2)
#expectRsqd_2Darray = np.sum(RsqdProb_3Darray,axis=2)
#expectRsqd_1Darray = np.sum(expectRsqd_2Darray,axis=0)
#expectStdDev_1Darray = np.sqrt(np.real(expectRsqd_1Darray-np.sum(expectR_2Darray**2,axis=0)))
#
##print expectR_2Darray[:,:5]
##print expectRcentred_2Darray[:,:5]
#
#################
##Calculate L
#################
#
## 1. Calculate distance of every site from the centre site
## 2. Sort sites and corresponding probability densities according to distance
## 3. Use cumulative sum and find index/distance where it first exceeds 90%. Make sure all numbers with same distance are included.
#
#vecDiffCentre3Darray = vec3Darray - expectR_2Darray.T #Dist from <r_vec>
#
#
#distFromCentre_2Darray = np.linalg.norm(vecDiffCentre3Darray,axis=2)
#
#sortedIndices_1Darray = np.lexsort(distFromCentre_2Darray.T,axis=-1)
#sortedDistFromCentre_2Darray = distFromCentre_2Darray[sortedIndices_1Darray,:]
#
#timePropdDensity_2Darray = np.real(timePropd_2Darray.conj()*timePropd_2Darray)
#sortedTimePropdDensity_2Darray = timePropdDensity_2Darray[sortedIndices_1Darray,:]
#
#cumSumSortedTimePropdDensity_2Darray = np.cumsum(sortedTimePropdDensity_2Darray,axis=0)
#
#L_index_1Darray = np.argmax(cumSumSortedTimePropdDensity_2Darray >= L_thresh,axis=0)
#L_value_1Darray = sortedDistFromCentre_2Darray[L_index_1Darray,np.arange(numTimeSteps)]
#L_pctg_1Darray = np.zeros_like(L_value_1Darray)
#
## for iter in range(numTimeSteps):
#    # L_value = L_value_1Darray[iter]
#    # L_index = L_index_1Darray[iter]
#    # L_siteIndex = sortedIndices_1Darray[iter]
#
#    # equidistantIndices_1Darray = np.nonzero(np.abs(sortedDistFromCentre_2Darray[:,iter]-L_value)<1E-10)[0]
#    # equidistantCumSum_1Darray = cumSumSortedTimePropdDensity_2Darray[equidistantIndices_1Darray,iter]
#
#    # L_pctg_1Darray[iter] = equidistantCumSum_1Darray[-1]
#
## L_trx_1Darray = 2*L_value_1Darray
###############
## Calculate L - TRX method
###############
#L_trx_1Darray = np.zeros(numTimeSteps)
#L_pctg_1Darray = np.zeros(numTimeSteps)
#
#for iter in range(numTimeSteps):
#    prob_1Darray = timePropdDensity_2Darray[:,iter]
#    norm = prob_1Darray.sum()
#   # print norm
#
#    uniqueDist_1Darray = np.unique(distFromCentre_2Darray[:,iter]) #NOTE: Some distances that should be the same, are treated as different (issue with comparing floats directly)
#    cumSum = 0
#
#    for dist_iter in range(0,uniqueDist_1Darray.size):
#        increment = prob_1Darray[np.where(uniqueDist_1Darray[dist_iter] ==distFromCentre_2Darray[:,iter])].sum()
#
#        cumSum += increment
#
#        if dist_iter==0:
#            if cumSum > L_thresh:
#                L_trx_1Darray[iter] = 0+((uniqueDist_1Darray[dist_iter]-0)*(L_thresh-cumSum+increment)/increment)
#                L_pctg_1Darray[iter] = cumSum
#                break
#
#        else:
#            if cumSum > L_thresh:
#                L_trx_1Darray[iter] = uniqueDist_1Darray[dist_iter-1]+((uniqueDist_1Darray[dist_iter]-uniqueDist_1Darray[dist_iter-1])*(L_thresh-cumSum+increment)/increment)
#                L_trx_1Darray[iter] *= 2.
#                L_pctg_1Darray[iter] = cumSum
#                break
#
##################
###Calculate L - TRX method - Vectorized attempt
##################
##print distFromCentre_2Darray.shape
##uniqueDist_1Darray = np.unique(distFromCentre_2Darray[:,0]) #NOTE: Some distances that should be the same, are treated as different (issue with comparing floats directly)
##uniqueDist_2Darray = np.tile(uniqueDist_1Darray,(numTimeSteps,1)).T
###print uniqueDist_1Darray
##cum_1Darray = np.zeros(numTimeSteps)
##R_min_1Darray = np.zeros(numTimeSteps)
##R_max_1Darray = np.zeros(numTimeSteps)
##mask_1Darray = np.ones(numTimeSteps,dtype=np.int_)
##L_trx_1Darray = np.zeros(numTimeSteps)
##
##for dist_iter in range(0,uniqueDist_1Darray.size):
##    increment = timePropdDensity_2Darray[np.where(distFromCentre_2Darray[:,0]==uniqueDist_1Darray[dist_iter]),:][0,:,:].sum(axis=0)
##
##    cum_1Darray = cum_1Darray + increment*mask_1Darray
##
##    L_trx_1Darray[np.where(np.logical_and(cum_1Darray>=L_thresh,mask_1Darray==1))] = 2.*uniqueDist_1Darray[dist_iter]
##    mask_1Darray = np.where(cum_1Darray<L_thresh,1,0)
##    print mask_1Darray
##    print L_trx_1Darray
#############################################
##    if dist_iter==0:
##        R_min_1Darray = np.zeros(numTimeSteps)
##        R_max_1Darray = np.where(cum_1Darray<L_thresh,uniqueDist_1Darray[dist_iter],np.inf)
##        L_trx_1Darray[np.where(cum_1Darray>=L_thresh)] = 2.*uniqueDist_1Darray[dist_iter]
##
##    else:
##        R_min_1Darray = np.where(cum_1Darray<L_thresh,uniqueDist_1Darray[dist_iter-1],-np.inf)
##        R_max_1Darray = np.where(cum_1Darray<L_thresh,uniqueDist_1Darray[dist_iter],np.inf)
##        L_trx_1Darray[np.where(cum_1Darray>=L_thresh)] = 2.*uniqueDist_1Darray[dist_iter]
#
##    print cum_1Darray
#
## ################
## #Calculate L - New method
## ################
#
## #Set up shells
## #Sum prob in new shell
## #Add to old prob
## #If now Greater than thresh, take outer shell as L_90%
## #Make shell sizes small enough that error is small for small changes in probdensity
#
## shellSpacing = 1E-4
## shellBorders_1Darray = np.arange(0,np.sqrt(3)*(N/2+1),shellSpacing)#np.linspace(0,np.sqrt(3)*N,numShells)
## numShells = shellBorders_1Darray.size
#
## L_new_1Darray = np.zeros(numTimeSteps)
## L_pctg_1Darray = np.zeros(numTimeSteps)
#
## vecDiffCentre3Darray = vec3Darray - expectR_2Darray.T #Dist from <r_vec>
## distFromCentre_2Darray = np.linalg.norm(vecDiffCentre3Darray,axis=2)
## timePropdDensity_2Darray = np.real(timePropd_2Darray.conj()*timePropd_2Darray)
#
## for iter in range(numTimeSteps):
#    # prob_1Darray = timePropdDensity_2Darray[:,iter]
#    # # print "-----------------------------------------------------------"
#
#    # for jiter in range(1,numShells):
#        # relevantProbs = prob_1Darray[np.logical_and(distFromCentre_2Darray[:,iter]<shellBorders_1Darray[jiter],distFromCentre_2Darray[:,iter]>=shellBorders_1Darray[jiter-1])]
#        # L_pctg_1Darray[iter] += np.sum(relevantProbs)
#
#        # # if iter == 0:
#            # # print shellBorders_1Darray[jiter-1], " < r < ", shellBorders_1Darray[jiter]
#            # # print distFromCentre_2Darray[:,iter]
#            # # print  np.logical_and(distFromCentre_2Darray[:,iter]<shellBorders_1Darray[jiter],distFromCentre_2Darray[:,iter]>=shellBorders_1Darray[jiter-1])
#            # # print L_pctg_1Darray[iter]
#
#        # if L_pctg_1Darray[iter] > L_thresh:
#            # L_new_1Darray[iter] = 2.*shellBorders_1Darray[jiter]
#            # # print "DONE"
#            # print L_new_1Darray[iter]
#            # break
#
#####################################################################################
##Save observables
#####################################################################################
#print "Saving Observables."
#
#filename = "dynamObservTRX"+generic_filename
#
#outputFile = open(outputDir+filename,'w')
#
#outputFile.write("#L_90% of amplitude of \n")
#outputFile.write("#{0}\n".format(filename))
#outputFile.write("#in directory: {0}\n".format(outputDir))
#outputFile.write("#time   actual_pct   L   IPR   <r_vec> <sigma_r>\n")
#
#for iter in range(numTimeSteps):
#    outputFile.write("{0:.16e}\t".format(time_1Darray[iter]))
##    outputFile.write("{0}\t".format(L_pctg_1Darray[iter]))
##    outputFile.write("{0}\t".format(2*L_value_1Darray[iter]))
#    outputFile.write("{0:.16e}\t".format(L_pctg_1Darray[iter]))
#    outputFile.write("{0:.16e}\t".format(L_trx_1Darray[iter]))
#    outputFile.write("{0:.16e}\t".format(IPR_2Darray[iter]))
#    outputFile.write(" #({0:.16e},\t".format(expectRcentred_2Darray[0,iter]))
#    outputFile.write("{0:.16e},\t".format(expectRcentred_2Darray[1,iter]))
#    outputFile.write("{0:.16e})\t".format(expectRcentred_2Darray[2,iter]))
#    outputFile.write("{0:.16e}\n".format(expectStdDev_1Darray[iter]))
#
#outputFile.close()
#print "Observables saved to : ", filename
#
#print " "




























